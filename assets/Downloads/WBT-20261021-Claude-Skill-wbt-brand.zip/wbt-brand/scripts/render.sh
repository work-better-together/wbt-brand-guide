#!/bin/bash
# Render a WBT HTML design with headless Chrome.
#   bash scripts/render.sh <file.html> <out.png> <width> <height>     PNG at the exact canvas size
#   bash scripts/render.sh <file.html> <out.pdf> --pdf                US Letter PDF, no margins, backgrounds on
#   TRANSPARENT=1 bash scripts/render.sh <file.html> <out.png> W H    transparent PNG (collages: the page and stage need no background)
# Phone widths (< 500px) render through an iframe, because headless Chrome can't lay out a window that narrow.
CHROME="${CHROME:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}"
[ -x "$CHROME" ] || CHROME="$(command -v google-chrome || command -v chromium || command -v chromium-browser)"
IN="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
if [ "$3" = "--pdf" ]; then
  "$CHROME" --headless=new --disable-gpu --no-pdf-header-footer --virtual-time-budget=8000 \
    --print-to-pdf="$2" "file://$IN" 2>/dev/null
  [ -s "$2" ] || { echo "render failed"; exit 1; }
  echo "$2 ($(pdfinfo "$2" 2>/dev/null | awk '/^Pages/{print $2}' || echo '?') page(s); one-pagers and worksheets must be 1)"
  exit 0
fi
W="$3"; H="$4"; URL="file://$IN"; WIN="$W"
if [ "$W" -lt 500 ]; then
  FRAME="$(dirname "$IN")/.phone-frame-$$.html"
  printf '<html><body style="margin:0"><iframe src="%s" style="border:0;width:%spx;height:%spx;display:block"></iframe></body></html>' \
    "$(basename "$IN")" "$W" "$H" > "$FRAME"
  URL="file://$FRAME"; WIN=500
fi
BG=""; [ -n "$TRANSPARENT" ] && BG="--default-background-color=00000000"
"$CHROME" --headless=new --disable-gpu --hide-scrollbars --force-device-scale-factor=1 $BG \
  --virtual-time-budget=8000 --window-size="$WIN,$H" --screenshot="$2" "$URL" 2>/dev/null
if [ -n "$FRAME" ]; then
  python3 -c "from PIL import Image; im=Image.open('$2'); im.crop((0,0,$W,$H)).save('$2')" 2>/dev/null || sips -c "$H" "$W" --cropOffset 0 0 "$2" >/dev/null
  mv "$FRAME" "${TMPDIR:-/tmp}/" 2>/dev/null
fi
[ -s "$2" ] && echo "$2" || { echo "render failed"; exit 1; }
