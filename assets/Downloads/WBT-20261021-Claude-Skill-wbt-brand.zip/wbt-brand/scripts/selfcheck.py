#!/usr/bin/env python3
"""WBT self-check: run on every HTML design before handing it over.

    python3 scripts/selfcheck.py design.html [--canvas 1080x1350]

Checks what can be checked from the file: type sizes against formats.md minimums for the canvas, fonts, colors,
art sources, copy (curly quotes, emoji, hype words), and the donts.md patterns. Prints one line per check and
exits 1 on any FAIL. Then look at the render yourself for what a script can't see: faces, crowding, balance.
"""
import re, sys, html as H, os

ALLOWED_FONTS = {'league spartan', 'lora', 'inconsolata', 'sans-serif', 'serif', 'monospace', 'inherit',
                 'arial', 'helvetica', 'georgia', 'times new roman', 'courier new'}   # last five: email fallbacks only
PALETTE = {'f9f8f2', '1f1e1e', '061a49', '2531a5', 'cd9f36', 'accdd9', '1e4d5c', 'b55312',          # brand
           'e0e8eb', 'f5e8d8', 'e8f0eb', 'fdf0ea', '6b6b6b', 'e4e2de', 'ffffff', '8c8c8c', 'f2f1eb',  # derived
           '856226', '4860c8', 'a15324', 'd8d6d2', '000000'}
# Minimum px per canvas width (formats.md). Key: canvas width.
MINIMUMS = {1080: 26, 1200: 24, 1920: 16, 816: 10, 600: 13, 640: 13, 1440: 12}
HYPE = ['elevate', 'unlock', 'supercharge', 'game-changer', 'game changer', 'seamless', 'cutting-edge', 'world-class',
        "today's fast-paced", 'act now', "don't miss out", 'so excited', 'synerg', 'leverage']
EMOJI = re.compile('[\U0001F300-\U0001FAFF☀-➿⭐✅✨]')

PROBE = r"""<script>
addEventListener('load', async () => {
  await document.fonts.ready; await new Promise(r => setTimeout(r, 600));
  const canvas = document.querySelector('.canvas') || document.body, cr = canvas.getBoundingClientRect();
  const own = e => [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim());
  const els = [...canvas.querySelectorAll('*')].filter(e => own(e) && getComputedStyle(e).visibility !== 'hidden' && e.getClientRects().length);
  const blocks = els.map(e => { const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
    return { e, r, size: parseFloat(cs.fontSize), fam: cs.fontFamily.split(',')[0].replace(/["']/g, '').trim(), t: e.textContent.trim().slice(0, 30) }; });
  const loaded = new Set([...document.fonts].filter(f => f.status === 'loaded').map(f => f.family.replace(/["']/g, '')));
  const unloaded = [...new Set(blocks.map(b => b.fam).filter(f => ['League Spartan', 'Lora', 'Inconsolata'].includes(f) && !loaded.has(f)))];
  const overlaps = [];
  for (let i = 0; i < blocks.length; i++) for (let j = i + 1; j < blocks.length; j++) {
    const a = blocks[i], b = blocks[j];
    if (a.e.contains(b.e) || b.e.contains(a.e)) continue;
    const x = Math.min(a.r.right, b.r.right) - Math.max(a.r.left, b.r.left), y = Math.min(a.r.bottom, b.r.bottom) - Math.max(a.r.top, b.r.top);
    if (x > 4 && y > 4) overlaps.push(a.t + ' × ' + b.t);
  }
  const outside = blocks.filter(b => b.r.left < cr.left - 1 || b.r.right > cr.right + 1 || b.r.top < cr.top - 1 || b.r.bottom > cr.bottom + 1).map(b => b.t);
  const imgs = [...document.images].filter(i => !i.complete || !i.naturalWidth).map(i => i.src.split('/').pop());
  // Art boxes (unrotated) for the art-over-text check; Python finds each file's ink from the asset catalog.
  const artBoxes = [...document.images].filter(i => i.naturalWidth && !/logo|monogram|wordmark|Spots|Background|Watercolor/i.test(decodeURIComponent(i.src) + ' ' + i.className))
    .map(im => { const tf = im.style.transform; im.style.transform = 'none'; const r = im.getBoundingClientRect(); im.style.transform = tf;
                 return { name: decodeURIComponent(im.src.split('/').pop()), src: im.src, x: r.left, y: r.top, w: r.width, h: r.height }; });
  const words = blocks.filter(b => b.size >= 24 && !/^\d/.test(b.t)).reduce((n, b) => n + b.e.textContent.trim().split(/\s+/).length, 0);
  // Logo clear space: no text block may touch a logo (with a 24px margin).
  const logoHits = [];
  for (const im of [...document.images].filter(i => i.naturalWidth && /logo|monogram|wordmark/i.test(decodeURIComponent(i.src) + ' ' + i.className))) {
    const r = im.getBoundingClientRect(), m = 24;
    for (const b of blocks) {
      // measure the rendered lines of text, not the block's box (a full-width box can pass a logo its words never reach)
      const rects = [...b.e.childNodes].filter(n => n.nodeType === 3 && n.textContent.trim()).flatMap(n => { const rg = document.createRange(); rg.selectNodeContents(n); return [...rg.getClientRects()]; });
      if (rects.some(t => Math.min(r.right + m, t.right) - Math.max(r.left - m, t.left) > 0 && Math.min(r.bottom + m, t.bottom) - Math.max(r.top - m, t.top) > 0))
        logoHits.push(b.t);
    }
  }
  // Boxed text: 3+ sibling boxes (border on 3+ sides, or a filled background different from their parent) each holding a heading and text.
  const boxed = [];
  const isBox = e => { const cs = getComputedStyle(e); const sides = ['Top','Right','Bottom','Left'].filter(sd => parseFloat(cs['border'+sd+'Width']) >= 1 && cs['border'+sd+'Style'] !== 'none').length;
    const bgc = cs.backgroundColor, pb = getComputedStyle(e.parentElement).backgroundColor;
    return sides >= 3 || (bgc !== 'rgba(0, 0, 0, 0)' && bgc !== pb && !cs.backgroundImage.includes('url')); };
  const holdsText = e => e.querySelector('h1,h2,h3,h4,h5,h6,strong,b,[class*=title],[class*=name]') && e.textContent.trim().split(/\s+/).length >= 8 && !e.querySelector('img,video,canvas,svg,input,button') && !e.closest('a,button');
  for (const parent of new Set([...canvas.querySelectorAll('*')].map(e => e.parentElement))) {
    const kids = [...parent.children].filter(k => isBox(k) && holdsText(k));
    if (kids.length >= 3) boxed.push(kids.length + ' boxes in ' + (parent.className || parent.tagName).toString().slice(0, 30));
  }
  const spotBoxes = [...document.images].filter(i => i.naturalWidth && /Spots/.test(decodeURIComponent(i.src)))
    .map(im => { const tf = im.style.transform; im.style.transform = 'none'; const r = im.getBoundingClientRect(); im.style.transform = tf;
                 return { name: decodeURIComponent(im.src.split('/').pop()), x: r.left, y: r.top, w: r.width, h: r.height }; });
  const textBoxes = blocks.map(b => ({ t: b.t, x: b.r.left, y: b.r.top, w: b.r.width, h: b.r.height }));
  const pre = document.createElement('pre'); pre.id = 'wbt-check';
  pre.textContent = JSON.stringify({ w: Math.round(cr.width), h: Math.round(cr.height), min: Math.min(...blocks.map(b => b.size)),
    small: blocks.map(b => [b.size, b.t]), unloaded, overlaps: overlaps.slice(0, 6), outside: outside.slice(0, 6), broken: imgs, artBoxes, spotBoxes, textBoxes, words, logoHits: [...new Set(logoHits)].slice(0, 6), boxed: boxed.slice(0, 6) });
  document.body.append(pre);
});
</script>"""

def rendered(path):
    """Render in headless Chrome with a probe script; returns measured facts or None if Chrome isn't available."""
    import subprocess, json, shutil
    chrome = os.environ.get('CHROME') or next((c for c in ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
              shutil.which('google-chrome') or '', shutil.which('chromium') or ''] if c and os.path.exists(c)), None)
    if not chrome:
        return None
    src = open(path, encoding='utf-8').read()
    tmp = os.path.join(os.path.dirname(os.path.abspath(path)), '.selfcheck-' + os.path.basename(path))
    open(tmp, 'w', encoding='utf-8').write(src.replace('</body>', PROBE + '</body>') if '</body>' in src else src + PROBE)
    try:
        out = subprocess.run([chrome, '--headless=new', '--disable-gpu', '--virtual-time-budget=10000', '--window-size=2400,2400',
                              '--dump-dom', 'file://' + tmp], capture_output=True, text=True, timeout=90).stdout
    finally:
        os.remove(tmp)
    m = re.search(r'<pre id="wbt-check">(.*?)</pre>', out, re.S)
    return json.loads(H.unescape(m.group(1))) if m else None

def art_over_text(r, path):
    """Scribbles and illustrations whose ink (from the asset catalog, or measured for local files) overlaps a text block."""
    cat = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'references', 'asset-catalog.md')
    ink = {}
    if os.path.exists(cat):
        for name, x0, x1, y0, y1 in re.findall(r'`([^`]+)` \d+×\d+ ink (\d+)–(\d+)%×(\d+)–(\d+)%', open(cat, encoding='utf-8').read()):
            ink[name] = tuple(int(v) / 100 for v in (x0, x1, y0, y1))
    hits = []
    for a in r.get('artBoxes', []):
        box = ink.get(a['name'])
        if box is None:
            local = os.path.join(os.path.dirname(os.path.abspath(path)), a['src'].replace('file://', '')) if a['src'].startswith('file:') else None
            box = (0, 1, 0, 1)
            if local and os.path.exists(a['src'].replace('file://', '')):
                try:
                    from PIL import Image
                    im = Image.open(a['src'].replace('file://', ''))
                    if im.mode in ('RGBA', 'LA'):
                        bb = im.getchannel('A').point(lambda v: 255 if v > 24 else 0).getbbox()
                        if bb: box = (bb[0] / im.width, bb[2] / im.width, bb[1] / im.height, bb[3] / im.height)
                except Exception:
                    pass
        ax0, ax1 = a['x'] + box[0] * a['w'], a['x'] + box[1] * a['w']
        ay0, ay1 = a['y'] + box[2] * a['h'], a['y'] + box[3] * a['h']
        for t in r.get('textBoxes', []):
            if min(ax1, t['x'] + t['w']) - max(ax0, t['x']) > 6 and min(ay1, t['y'] + t['h']) - max(ay0, t['y']) > 6:
                hits.append(f"{a['name'][:28]} × {t['t']}")
    return sorted(set(hits))[:6]

def stray_scribbles(r):
    """Scribbles whose ink mostly misses every spot's ink (they should sit over the spot, under the illustration)."""
    cat = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'references', 'asset-catalog.md')
    ink = {n: tuple(int(v) / 100 for v in b) for n, *b in re.findall(r'`([^`]+)` \d+×\d+ ink (\d+)–(\d+)%×(\d+)–(\d+)%', open(cat, encoding='utf-8').read())} if os.path.exists(cat) else {}
    box = lambda a: (lambda f: (a['x'] + f[0] * a['w'], a['x'] + f[1] * a['w'], a['y'] + f[2] * a['h'], a['y'] + f[3] * a['h']))(ink.get(a['name'], (0, 1, 0, 1)))
    out = []
    spots = [box(s) for s in r.get('spotBoxes', [])]
    for a in r.get('artBoxes', []):
        if 'scribble' not in a['name'].lower() or not spots:
            continue
        x0, x1, y0, y1 = box(a); area = max(1, (x1 - x0) * (y1 - y0))
        best = max(max(0, min(x1, s[1]) - max(x0, s[0])) * max(0, min(y1, s[3]) - max(y0, s[2])) for s in spots) / area
        widest = max(s[1] - s[0] for s in spots)
        if best < 0.4:
            out.append(f"{a['name'][:30]} ({best:.0%} over a spot)")
        elif (x1 - x0) > 1.5 * widest:
            out.append(f"{a['name'][:30]} (ink {(x1 - x0) / widest:.1f}× the spot's width: it trails off)")
    return out

def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    path = args[0]
    src = open(path, encoding='utf-8').read()
    css = ' '.join(re.findall(r'<style[^>]*>(.*?)</style>', src, re.S)) + ' ' + ' '.join(re.findall(r'style="([^"]*)"', src))
    for link in re.findall(r'<link[^>]+href="([^"]+\.css)"', src):
        p = os.path.join(os.path.dirname(path), link)
        if os.path.exists(p):
            css += ' ' + open(p, encoding='utf-8').read()
    body = re.sub(r'<(style|script)[^>]*>.*?</\1>', ' ', src, flags=re.S)
    body = re.sub(r'<!--.*?-->', ' ', body, flags=re.S)
    text = H.unescape(re.sub(r'<[^>]+>', ' ', body))
    results = []
    def check(name, ok, detail='', warn=False):
        results.append(('PASS' if ok else ('WARN' if warn else 'FAIL'), name, detail))

    # Canvas
    canvas = None
    if '--canvas' in args:
        canvas = int(args[args.index('--canvas') + 1].lower().split('x')[0])
    else:
        m = re.search(r'\.canvas\s*\{[^}]*width:\s*(\d+)px', css)
        canvas = int(m.group(1)) if m else None
    minimum = MINIMUMS.get(canvas)

    # 1. Rendered checks: real type sizes, fonts loaded, overlaps, off-canvas text, broken images
    r = rendered(path)
    if r:
        canvas = canvas or r['w']
        minimum = MINIMUMS.get(canvas)
        if canvas == 1080 and r['h'] >= 1900:
            minimum = 26      # Story / Reel: bigger minimum than a feed post
        if minimum:
            small = sorted({f'{sz:g}px “{t}”' for sz, t in r['small'] if sz < minimum})
            check(f'type ≥ {minimum}px on a {canvas}×{r["h"]} canvas', not small, f'too small: {small[:4]}' if small else f'smallest {r["min"]:g}px')
        check('brand fonts loaded (not fallen back)', not r['unloaded'], f'not loaded: {r["unloaded"]}: keep templates/, fonts/ and logos/ together' if r['unloaded'] else '')
        check('no overlapping text', not r['overlaps'], f'{r["overlaps"]}' if r['overlaps'] else '')
        if canvas == 1080 and r['h'] >= 1900:
            unsafe = [t['t'] for t in r.get('textBoxes', []) if t['y'] < 250 or t['y'] + t['h'] > 1580]
            check('Story safe zones (text between y 250 and 1580)', not unsafe, f'{unsafe[:4]}' if unsafe else '')
        check('text inside the canvas', not r['outside'], f'{r["outside"]}' if r['outside'] else '')
        check('logo clear space (no text within 24px of a logo)', not r.get('logoHits'), f"{r.get('logoHits')}" if r.get('logoHits') else '')
        check('no boxed text grids (open columns, not cards)', not r.get('boxed'), f"{r.get('boxed')}: drop the boxes; use space or a 1px top rule" if r.get('boxed') else '')
        check('images load', not r['broken'], f'{r["broken"]}' if r['broken'] else '')
        if canvas == 1920:
            check('≤ 40 words a slide (60 for an agenda)', r.get('words', 0) <= 40, f"{r.get('words')} words: split the slide unless it's a day's agenda", warn=True)
        stray = stray_scribbles(r)
        check('scribble sits over the spot (not trailing off)', not stray, f'{stray}: centre its ink on the spot' if stray else '')
        r['art'] = art_over_text(r, path)
        check('art stays off the text', not r.get('art'), f'ink under text: {r["art"]}: move the art or confirm it sits behind as a quiet bleed' if r.get('art') else '', warn=True)
    else:
        sizes = [float(v) for v in re.findall(r'font-size:\s*([0-9.]+)px', css)]
        small = sorted({x for x in sizes if minimum and x < minimum})
        check('type sizes (static; Chrome not found)', not small, f'too small: {small}' if small else '', warn=not minimum)

    # 2. Fonts
    fams = set()
    for decl in re.findall(r'font-family:\s*([^;}"]+)', css):
        for f in decl.split(','):
            f = f.strip().strip('\'"').lower()
            if f and not f.startswith('var('):
                fams.add(f)
    bad = sorted(fams - ALLOWED_FONTS)
    check('only League Spartan, Lora, Inconsolata', not bad, f'other fonts: {bad}' if bad else '')

    # 3. Colors
    hexes = {h.lower() if len(h) == 6 else ''.join(c * 2 for c in h.lower()) for h in re.findall(r'#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b', css)}
    off = sorted(hexes - PALETTE)
    check('colors from the WBT palette', not off, f'off-palette: {off}' if off else '', warn=True)

    # 4. Art sources: official files only
    srcs = re.findall(r'<img[^>]+src="([^"]+)"', src) + re.findall(r'url\([\'"]?([^\'")]+)', css)
    srcs = [s for s in srcs if not s.endswith(('.ttf', '.otf', '.woff', '.woff2', '.css'))]
    cat = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'references', 'asset-catalog.md')
    known = set(re.findall(r'`([^`]+\.(?:png|jpe?g|svg|webp))`', open(cat, encoding='utf-8').read())) if os.path.exists(cat) else set()
    unofficial = [s for s in srcs if not (s.startswith('https://brand.wbt.coach/assets/') or 'logos/' in s or
                  os.path.basename(s.split('?')[0]) in known or
                  'WBT-' in s or 'workbettertogether.coach' in s or s.startswith('data:image/svg'))]
    check('art is official WBT files', not unofficial, f'check these are WBT-owned: {unofficial[:5]}' if unofficial else '', warn=True)
    drawn = re.findall(r'<svg[^>]*>.*?</svg>', src, re.S)
    drawn = [d for d in drawn if re.search(r'<(path|circle|ellipse|polyline|line)\b', d) and 'aria-hidden' not in d[:200]]
    check('no hand-drawn SVG stand-ins', not drawn, f'{len(drawn)} inline SVG drawing(s): use the asset catalog file instead' if drawn else '', warn=True)

    # 5. Copy
    straight = re.findall(r"[A-Za-z]'[A-Za-z]|\"[^\"]{2,}\"", text)
    check('curly quotes', not straight, f'straight quotes: {straight[:3]}' if straight else '')
    emoji = EMOJI.findall(text)
    check('no emoji', not emoji, ''.join(emoji[:8]))
    hype = [w for w in HYPE if w in text.lower()]
    check('no hype words', not hype, f'{hype}' if hype else '')
    people = re.findall(r'\b(silhouettes?|avatars?|personas?|stand-ins?|placeholder (?:person|people))\b', src, re.I)
    check('no placeholder people', not people, f'{set(people)}' if people else '')

    # 6. donts.md patterns
    check('no dashed or dotted borders', not re.search(r'border[^;]*:\s*[^;]*\b(dashed|dotted)', css))
    grads = re.findall(r'(linear|radial|conic)-gradient\(([^;]*)', css)
    deco = [g for g in grads if 'transparent' not in g[1] and 'rgba' not in g[1]]
    check('gradients only as photo scrims', not deco, f'{len(deco)} decorative gradient(s)' if deco else '', warn=bool(grads) and not deco)
    check('no glows or glass', not re.search(r'backdrop-filter|text-shadow:\s*0 0 \d+px', css))
    check('scribbles not recolored', not re.search(r'scribble[^}]*\{[^}]*filter:\s*(invert|brightness)', css, re.S) and
          not re.search(r'class="[^"]*scribble[^"]*"[^>]*style="[^"]*filter', src))
    counters = re.findall(r'>\s*0[1-9]\s*[·.:/-]?\s*<', src)
    check('no 01/02 decorative counters', not counters, 'only number a real sequence' if counters else '', warn=True)

    fails = 0
    for status, name, detail in results:
        print(f'{status:4}  {name}' + (f'  ({detail})' if detail else ''))
        fails += status == 'FAIL'
    print(f'\n{len(results)} checks, {fails} failed. Now look at the render: faces clear, nothing crowded, text off the art.')
    sys.exit(1 if fails else 0)

if __name__ == '__main__':
    main()
