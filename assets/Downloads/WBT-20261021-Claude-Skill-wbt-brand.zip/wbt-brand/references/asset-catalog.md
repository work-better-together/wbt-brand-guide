# WBT asset catalog

Generated from the brand guide by `build/make_catalog.py`. Do not hand-edit.

## How to get a file

1. **Live brand guide (default):** `https://brand.wbt.coach/assets/<folder>/<file>`, spaces encoded as `%20`. Every row below gives the folder; the full URL is the folder URL plus the file name. Download it (curl, fetch or your file tool), then place it.
2. **Google Drive:** the same files sit in the shared drive folder `Work Better Together/Brand/2026 WBT Brand Guide/assets/`, same folder names. With a Drive connector, search by the exact file name.
3. **If neither works** (some Claude environments block network access): say which file you need and ask the user to upload it. Never draw a stand-in.

Sizes are pixels (W×H). `ink 12–88%×30–64%` means the visible ink spans 12–88% of the width and 30–64% of the height (transparent margin around it); place and crop by the ink, not the canvas. Scribbles also give `line N`: the stroke thickness in px when the file is 1920 wide. Prefer thin ones (line ≤ 10); heavy ones (≥ 13) overpower a collage. Check orientation: a wide scribble won't fit a tall slot.

## Logos (7)

Wordmark, monogram and favicon. Recolor by swapping the fill; never redraw.

### Logos/

Folder URL: https://brand.wbt.coach/assets/Logos/ (add the file name, spaces as %20)

`WBT-20260502-WBT-Monogram-Black.svg` svg, `WBT-20260502-WBT-Monogram-Clear-White.svg` svg, `WBT-20260502-Work-Better-Together-Wordmark-Black.svg` svg, `WBT-20260502-Work-Better-Together-Wordmark-Clear-White.svg` svg, `WBT-20260505-Favicon-Intentional-Blue.svg` svg, `WBT-Favicon-Intentional-Blue.png` 300×300, `apple-touch-icon.png` 800×800

## Watercolor Textures/Spots (63)

Transparent watercolor spots, the bottom layer of every collage. One named color per collage.

### Watercolor Textures/Spots/Calm Blue/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Spots/Calm%20Blue/ (add the file name, spaces as %20)

`WBT-20260403-Calm-Blue-Watercolor-Spots-1.png` 1000×1141 ink 4–94%×5–98%, `WBT-20260403-Calm-Blue-Watercolor-Spots-2.png` 1000×1057, `WBT-20260403-Calm-Blue-Watercolor-Spots-3.png` 1000×1057 ink 7–97%×15–86%, `WBT-20260403-Calm-Blue-Watercolor-Spots-4.png` 1000×1057 ink 7–94%×9–92%, `WBT-20260403-Calm-Blue-Watercolor-Spots-5.png` 1920×1080 ink 15–62%×10–85%, `WBT-20260403-Calm-Blue-Watercolor-Spots-6.png` 500×500 ink 3–100%×16–93%, `WBT-20260403-Calm-Blue-Watercolor-Spots-7.png` 1920×1080 ink 7–65%×13–86%, `WBT-20260403-Calm-Blue-Watercolor-Spots-8.png` 1677×1155 ink 7–96%×6–93%, `WBT-20260403-Calm-Blue-Watercolor-Spots-9.png` 2048×2048 ink 12–88%×9–99%

### Watercolor Textures/Spots/Clean Slate/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Spots/Clean%20Slate/ (add the file name, spaces as %20)

`WBT-20260403-Clean-Slate-Watercolor-Spots-1.png` 1000×1141 ink 4–94%×5–98%, `WBT-20260403-Clean-Slate-Watercolor-Spots-2.png` 1000×1057, `WBT-20260403-Clean-Slate-Watercolor-Spots-3.png` 1000×1057 ink 7–97%×15–86%, `WBT-20260403-Clean-Slate-Watercolor-Spots-4.png` 1000×1057 ink 7–94%×9–92%, `WBT-20260403-Clean-Slate-Watercolor-Spots-5.png` 1920×1080 ink 15–62%×10–85%, `WBT-20260403-Clean-Slate-Watercolor-Spots-6.png` 500×500 ink 3–100%×16–93%, `WBT-20260403-Clean-Slate-Watercolor-Spots-7.png` 1920×1080 ink 7–65%×13–86%, `WBT-20260403-Clean-Slate-Watercolor-Spots-8.png` 1677×1155 ink 7–96%×6–93%, `WBT-20260403-Clean-Slate-Watercolor-Spots-9.png` 2048×2048 ink 12–88%×9–99%

### Watercolor Textures/Spots/Grounded Black/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Spots/Grounded%20Black/ (add the file name, spaces as %20)

`WBT-20260403-Grounded-Black-Watercolor-Spots-1.png` 1274×1268 ink 8–90%×3–100%, `WBT-20260403-Grounded-Black-Watercolor-Spots-2.png` 1274×1268, `WBT-20260403-Grounded-Black-Watercolor-Spots-3.png` 1274×1268 ink 8–96%×13–87%, `WBT-20260403-Grounded-Black-Watercolor-Spots-4.png` 1274×1268, `WBT-20260403-Grounded-Black-Watercolor-Spots-5.png` 1920×1080 ink 15–62%×10–85%, `WBT-20260403-Grounded-Black-Watercolor-Spots-6.png` 500×500 ink 3–100%×16–93%, `WBT-20260403-Grounded-Black-Watercolor-Spots-7.png` 1920×1080 ink 7–65%×13–86%, `WBT-20260403-Grounded-Black-Watercolor-Spots-8.png` 1677×1155 ink 7–96%×6–93%, `WBT-20260403-Grounded-Black-Watercolor-Spots-9.png` 2048×2048 ink 12–88%×9–99%

### Watercolor Textures/Spots/Honest Ochre/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Spots/Honest%20Ochre/ (add the file name, spaces as %20)

`WBT-20260403-Honest-Ochre-Watercolor-Spots-1.png` 1000×1141 ink 5–93%×7–98%, `WBT-20260403-Honest-Ochre-Watercolor-Spots-2.png` 1000×1057, `WBT-20260403-Honest-Ochre-Watercolor-Spots-3.png` 1000×1057 ink 7–98%×15–87%, `WBT-20260403-Honest-Ochre-Watercolor-Spots-4.png` 1000×1057 ink 7–94%×9–92%, `WBT-20260403-Honest-Ochre-Watercolor-Spots-5.png` 1920×1080 ink 15–62%×10–85%, `WBT-20260403-Honest-Ochre-Watercolor-Spots-6.png` 500×500 ink 3–100%×16–93%, `WBT-20260403-Honest-Ochre-Watercolor-Spots-7.png` 1920×1080 ink 7–65%×13–86%, `WBT-20260403-Honest-Ochre-Watercolor-Spots-8.png` 1677×1155 ink 7–96%×6–93%, `WBT-20260403-Honest-Ochre-Watercolor-Spots-9.png` 2048×2048 ink 12–88%×9–99%

### Watercolor Textures/Spots/Intentional Blue/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Spots/Intentional%20Blue/ (add the file name, spaces as %20)

`WBT-20260403-Intentional-Blue-Watercolor-Spots-1.png` 1000×1141 ink 4–94%×5–98%, `WBT-20260403-Intentional-Blue-Watercolor-Spots-2.png` 1000×1057, `WBT-20260403-Intentional-Blue-Watercolor-Spots-3.png` 1000×1057 ink 7–97%×15–86%, `WBT-20260403-Intentional-Blue-Watercolor-Spots-4.png` 1000×1057 ink 7–94%×9–92%, `WBT-20260403-Intentional-Blue-Watercolor-Spots-5.png` 1920×1080 ink 15–62%×10–85%, `WBT-20260403-Intentional-Blue-Watercolor-Spots-6.png` 500×500 ink 3–100%×16–93%, `WBT-20260403-Intentional-Blue-Watercolor-Spots-7.png` 1920×1080 ink 7–65%×13–86%, `WBT-20260403-Intentional-Blue-Watercolor-Spots-8.png` 1677×1155 ink 7–96%×6–93%, `WBT-20260403-Intentional-Blue-Watercolor-Spots-9.png` 2048×2048 ink 12–88%×9–99%

### Watercolor Textures/Spots/Radiant Gold/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Spots/Radiant%20Gold/ (add the file name, spaces as %20)

`WBT-20260403-Gold-Watercolor-Spots-1.png` 1000×1141 ink 4–94%×5–98%, `WBT-20260403-Gold-Watercolor-Spots-2.png` 1000×1057, `WBT-20260403-Gold-Watercolor-Spots-3.png` 1000×1057 ink 7–97%×15–86%, `WBT-20260403-Gold-Watercolor-Spots-4.png` 1000×1057 ink 7–94%×9–92%, `WBT-20260403-Gold-Watercolor-Spots-5.png` 1920×1080 ink 15–62%×10–85%, `WBT-20260403-Gold-Watercolor-Spots-6.png` 500×500 ink 3–100%×16–93%, `WBT-20260403-Gold-Watercolor-Spots-7.png` 1920×1080 ink 7–65%×13–86%, `WBT-20260403-Gold-Watercolor-Spots-8.png` 1677×1155 ink 7–96%×6–93%, `WBT-20260403-Gold-Watercolor-Spots-9.png` 2048×2048 ink 12–88%×9–99%

### Watercolor Textures/Spots/Steady Blue/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Spots/Steady%20Blue/ (add the file name, spaces as %20)

`WBT-20260403-Steady-Blue-Watercolor-Spots-1.png` 1000×1141 ink 4–94%×5–98%, `WBT-20260403-Steady-Blue-Watercolor-Spots-2.png` 1000×1057, `WBT-20260403-Steady-Blue-Watercolor-Spots-3.png` 1000×1057 ink 7–97%×15–86%, `WBT-20260403-Steady-Blue-Watercolor-Spots-4.png` 283×299 ink 7–94%×9–92%, `WBT-20260403-Steady-Blue-Watercolor-Spots-5.png` 1920×1080 ink 15–62%×10–85%, `WBT-20260403-Steady-Blue-Watercolor-Spots-6.png` 500×500 ink 3–100%×16–93%, `WBT-20260403-Steady-Blue-Watercolor-Spots-7.png` 1920×1080 ink 7–65%×13–86%, `WBT-20260403-Steady-Blue-Watercolor-Spots-8.png` 1677×1155 ink 7–96%×6–93%, `WBT-20260403-Steady-Blue-Watercolor-Spots-9.png` 2048×2048 ink 12–88%×9–99%

## Watercolor Textures/Backgrounds (14)

Full-bleed watercolor washes for backgrounds.

### Watercolor Textures/Backgrounds/Calm Blue/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Backgrounds/Calm%20Blue/ (add the file name, spaces as %20)

`WBT-20260403-Calm-Blue-Watercolor-Background-1.jpg` 3000×1677, `WBT-20260403-Calm-Blue-Watercolor-Background-2.jpg` 3000×1677

### Watercolor Textures/Backgrounds/Clean Slate/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Backgrounds/Clean%20Slate/ (add the file name, spaces as %20)

`WBT-20260403-Clean-Slate-Watercolor-Background-1.jpg` 3000×1677, `WBT-20260403-Clean-Slate-Watercolor-Background-2.jpg` 3000×1677

### Watercolor Textures/Backgrounds/Grounded Black/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Backgrounds/Grounded%20Black/ (add the file name, spaces as %20)

`WBT-20260403-Grounded-Black-Watercolor-Background-1.jpg` 3000×1677, `WBT-20260403-Grounded-Black-Watercolor-Background-2.jpg` 3000×1677

### Watercolor Textures/Backgrounds/Honest Ochre/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Backgrounds/Honest%20Ochre/ (add the file name, spaces as %20)

`WBT-20260403-Honest-Ochre-Watercolor-Background-1.jpg` 3000×1677, `WBT-20260403-Honest-Ochre-Watercolor-Background-2.jpg` 3000×1677

### Watercolor Textures/Backgrounds/Intentional Blue/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Backgrounds/Intentional%20Blue/ (add the file name, spaces as %20)

`WBT-20260403-Intentional-Blue-Watercolor-Background-1.jpg` 3000×1677, `WBT-20260403-Intentional-Blue-Watercolor-Background-2.jpg` 3000×1677

### Watercolor Textures/Backgrounds/Radiant Gold/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Backgrounds/Radiant%20Gold/ (add the file name, spaces as %20)

`WBT-20260403-Gold-Watercolor-Background-1.jpg` 3000×1677, `WBT-20260403-Gold-Watercolor-Background-2.jpg` 3000×1677

### Watercolor Textures/Backgrounds/Steady Blue/

Folder URL: https://brand.wbt.coach/assets/Watercolor%20Textures/Backgrounds/Steady%20Blue/ (add the file name, spaces as %20)

`WBT-20260403-Steady-Blue-Watercolor-Background-1.jpg` 3000×1677, `WBT-20260403-Steady-Blue-Watercolor-Background-2.jpg` 3000×1677

## Scribbles (324)

Thin black hand-drawn lines, the middle collage layer and decorative bleeds. Never over live text.

### Scribbles/Backgrounds/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Backgrounds/ (add the file name, spaces as %20)

`WBT-scribble-background-01.png` 2400×1667, `WBT-scribble-background-02.png` 2400×1655, `WBT-scribble-background-03.png` 2400×1706, `WBT-scribble-background-04.png` 2400×1779, `WBT-scribble-background-05.png` 2400×1809, `WBT-scribble-background-06.png` 2400×1530, `WBT-scribble-background-07.png` 2400×1866, `WBT-scribble-background-08.png` 2400×1400, `WBT-scribble-background-09.png` 2400×1711, `WBT-scribble-background-10.png` 2400×751, `WBT-scribble-background-11.png` 2400×833, `WBT-scribble-background-12.png` 2400×1693, `WBT-scribble-background-13.png` 2400×1733, `WBT-scribble-background-14.png` 2400×3335, `WBT-scribble-background-15.png` 2400×1660, `WBT-scribble-background-16.png` 2400×1698, `WBT-scribble-background-17.png` 2400×1842, `WBT-scribble-background-18.png` 2400×2215, `WBT-scribble-background-19.png` 2400×1689, `WBT-scribble-background-20.png` 2400×1689 ink 4–97%×7–96%, `WBT-scribble-background-21.png` 2400×1117

### Scribbles/Blocks/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Blocks/ (add the file name, spaces as %20)

`WBT-scribble-block-01.png` 3085×2200, `WBT-scribble-block-02.png` 1476×1500 ink 8–95%×6–93%, `WBT-scribble-block-03.png` 2898×1953, `WBT-scribble-block-04.png` 1786×1000 ink 1–97%×7–92% line 27, `WBT-scribble-block-05.png` 2751×2000, `WBT-scribble-block-06.png` 2980×2300, `WBT-scribble-block-07.png` 2389×2500, `WBT-scribble-block-08.png` 3374×3200, `WBT-scribble-block-09.png` 2605×2000, `WBT-scribble-block-10.png` 2623×1500, `WBT-scribble-block-11.png` 2396×2300, `WBT-scribble-block-12.png` 2706×2200, `WBT-scribble-block-13.png` 3424×3000, `WBT-scribble-block-14.png` 2339×2000, `WBT-scribble-block-15.png` 3770×3000, `WBT-scribble-block-16.png` 1080×1100 line 28, `WBT-scribble-block-17.png` 3896×2300, `WBT-scribble-block-18.png` 4356×3500, `WBT-scribble-block-19.png` 3695×2100, `WBT-scribble-block-20.png` 4599×2100, `WBT-scribble-block-21.png` 2919×3100, `WBT-scribble-block-22.png` 3251×3100 ink 7–95%×4–95%, `WBT-scribble-block-23.png` 1848×1800, `WBT-scribble-block-24.png` 1528×500 line 45, `WBT-scribble-block-25.png` 1810×600 line 31, `WBT-scribble-block-26.png` 5785×1000, `WBT-scribble-block-27.png` 1500×400 ink 1–100%×10–92% line 27, `WBT-scribble-block-28.png` 2416×600 line 18, `WBT-scribble-block-29.png` 1157×1800, `WBT-scribble-block-30.png` 2483×1100 ink 0–98%×5–94%, `WBT-scribble-block-31.png` 3326×800, `WBT-scribble-block-32.png` 2169×600 ink 2–98%×5–91% line 19, `WBT-scribble-block-33.png` 2933×500 ink 3–100%×8–86% line 14, `WBT-scribble-block-34.png` 2535×500 line 14, `WBT-scribble-block-35.png` 2904×500 ink 2–98%×7–90% line 12, `WBT-scribble-block-36.png` 2956×500 ink 0–100%×6–90% line 13, `WBT-scribble-block-37.png` 2406×800 ink 1–100%×9–93%, `WBT-scribble-block-38.png` 2894×600 ink 2–98%×17–88% line 15

### Scribbles/Botanical/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Botanical/ (add the file name, spaces as %20)

`WBT-scribble-sweep-with-leaves.png` 1920×1080 ink 5–93%×11–89% line 10, `WBT-scribble-swooping-line-leaves.png` 1920×1080 ink 5–93%×11–89% line 10

### Scribbles/Chaotic/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Chaotic/ (add the file name, spaces as %20)

`WBT-scribble-chaotic-01.png` 1702×1800, `WBT-scribble-chaotic-02.png` 1935×1700, `WBT-scribble-chaotic-03.png` 1862×1500, `WBT-scribble-chaotic-04.png` 2649×2000, `WBT-scribble-chaotic-05.png` 4065×3700, `WBT-scribble-chaotic-06.png` 3820×3000, `WBT-scribble-chaotic-07.png` 4176×2500, `WBT-scribble-chaotic-08.png` 3588×3200, `WBT-scribble-chaotic-09.png` 1997×2100, `WBT-scribble-chaotic-10.png` 2571×2500, `WBT-scribble-chaotic-11.png` 2968×2000, `WBT-scribble-chaotic-12.png` 2540×1800, `WBT-scribble-chaotic-13.png` 2595×1800 ink 4–96%×5–94%, `WBT-scribble-chaotic-14.png` 2523×1800, `WBT-scribble-chaotic-15.png` 2943×1800 ink 4–97%×5–91%, `WBT-scribble-chaotic-16.png` 2297×2400, `WBT-scribble-chaotic-17.png` 3143×2300 ink 2–96%×6–92%, `WBT-scribble-chaotic-18.png` 2677×2200 ink 5–96%×8–93%, `WBT-scribble-chaotic-19.png` 2872×2000, `WBT-scribble-chaotic-20.png` 2958×1600, `WBT-scribble-chaotic-21.png` 2705×1800, `WBT-scribble-chaotic-22.png` 3190×2400, `WBT-scribble-chaotic-23.png` 2409×1800, `WBT-scribble-chaotic-24.png` 2579×2200, `WBT-scribble-chaotic-25.png` 2846×2200, `WBT-scribble-chaotic-26.png` 2678×2500 ink 5–95%×4–93%, `WBT-scribble-chaotic-27.png` 2184×1800, `WBT-scribble-chaotic-28.png` 2973×1500, `WBT-scribble-chaotic-29.png` 3596×1500, `WBT-scribble-chaotic-30.png` 2553×2500, `WBT-scribble-chaotic-31.png` 2641×2000, `WBT-scribble-chaotic-32.png` 2904×2500, `WBT-scribble-chaotic-33.png` 3657×3000, `WBT-scribble-chaotic-34.png` 5307×4000, `WBT-scribble-chaotic-35.png` 4134×3100, `WBT-scribble-chaotic-36.png` 2920×3200, `WBT-scribble-chaotic-37.png` 3279×2300, `WBT-scribble-chaotic-38.png` 2940×3000, `WBT-scribble-chaotic-39.png` 2876×2500, `WBT-scribble-chaotic-40.png` 1791×1800 ink 9–94%×6–94%, `WBT-scribble-chaotic-41.png` 2884×1800, `WBT-scribble-chaotic-42.png` 2937×1100 line 15, `WBT-scribble-chaotic-43.png` 1670×1100 line 27, `WBT-scribble-chaotic-44.png` 2705×1300, `WBT-scribble-chaotic-45.png` 4303×2300, `WBT-scribble-chaotic-46.png` 3893×1400, `WBT-scribble-chaotic-47.png` 4467×3000, `WBT-scribble-chaotic-48.png` 5226×1400, `WBT-scribble-chaotic-49.png` 6394×2300, `WBT-scribble-chaotic-50.png` 5286×2000, `WBT-scribble-chaotic-51.png` 5240×2100, `WBT-scribble-chaotic-52.png` 6012×2200, `WBT-scribble-chaotic-53.png` 3417×2300, `WBT-scribble-chaotic-54.png` 3859×3100, `WBT-scribble-chaotic-55.png` 2801×3500, `WBT-scribble-chaotic-56.png` 2698×2300, `WBT-scribble-chaotic-57.png` 3386×1300 ink 3–95%×6–91%, `WBT-scribble-chaotic-58.png` 2917×800 ink 0–100%×8–90%, `WBT-scribble-chaotic-59.png` 5789×700, `WBT-scribble-chaotic-60.png` 5767×900, `WBT-scribble-chaotic-61.png` 8124×650, `WBT-scribble-chaotic-62.png` 1827×600 ink 1–99%×13–98% line 17, `WBT-scribble-chaotic-63.png` 4153×800

### Scribbles/Hearts/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Hearts/ (add the file name, spaces as %20)

`WBT-scribble-heart-black-converted.png` 1920×1080 ink 29–64%×8–84% line 15, `WBT-scribble-heart-black.png` 1200×1200 ink 17–83%×23–81%, `WBT-scribble-heart-blue.png` 1920×1080 ink 29–64%×8–84%

### Scribbles/Lines/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Lines/ (add the file name, spaces as %20)

`WBT-scribble-line-01.png` 3000×379 line 13, `WBT-scribble-line-02.png` 3200×383 line 12, `WBT-scribble-line-03.png` 1934×400 line 19, `WBT-scribble-line-04.png` 2010×350 line 18, `WBT-scribble-line-05.png` 2700×419 line 13, `WBT-scribble-line-06.png` 2500×395 line 15, `WBT-scribble-line-07.png` 4175×1500, `WBT-scribble-line-08.png` 5578×1500, `WBT-scribble-line-09.png` 3417×1500, `WBT-scribble-line-10.png` 3548×1300 line 14, `WBT-scribble-line-11.png` 3520×1300, `WBT-scribble-line-12.png` 3326×800, `WBT-scribble-line-13.png` 3149×1000, `WBT-scribble-line-14.png` 7989×2000, `WBT-scribble-line-15.png` 2078×450 ink 0–99%×10–98% line 19, `WBT-scribble-line-16.png` 5598×800, `WBT-scribble-line-17.png` 5372×900, `WBT-scribble-line-18.png` 7553×850, `WBT-scribble-line-19.png` 5242×500 ink 0–100%×12–91%, `WBT-scribble-line-20.png` 5432×500, `WBT-scribble-line-21.png` 5353×300, `WBT-scribble-line-22.png` 5008×400 line 10, `WBT-scribble-line-23.png` 8421×300 ink 0–100%×6–95% line 8, `WBT-scribble-line-24.png` 1638×200 ink 1–99%×18–95% line 23, `WBT-scribble-line-25.png` 3003×200 ink 0–99%×5–84% line 12, `WBT-scribble-line-26.png` 3650×200 ink 1–100%×20–76% line 11, `WBT-scribble-line-27.png` 5353×200 ink 0–100%×6–72% line 8, `WBT-scribble-line-28.png` 6289×230 ink 0–100%×7–94% line 9, `WBT-scribble-line-29.png` 5893×200 ink 0–100%×5–94% line 8, `WBT-scribble-line-30.png` 3683×150 ink 0–100%×13–91% line 10, `WBT-scribble-line-31.png` 4285×200 ink 0–100%×12–80% line 9, `WBT-scribble-line-32.png` 2400×227 ink 0–100%×7–96% line 17, `WBT-scribble-line-33.png` 2435×400 line 16, `WBT-scribble-line-34.png` 2600×524 line 13, `WBT-scribble-line-35.png` 2200×603 line 18, `WBT-scribble-line-36.png` 2700×703 line 13, `WBT-scribble-line-37.png` 5348×800, `WBT-scribble-line-38.png` 4691×700 line 12, `WBT-scribble-line-39.png` 4589×1700, `WBT-scribble-line-40.png` 2831×2000, `WBT-scribble-line-41.png` 3495×2000, `WBT-scribble-line-42.png` 5230×1300, `WBT-scribble-line-43.png` 3200×918, `WBT-scribble-line-44.png` 3600×1229, `WBT-scribble-line-45.png` 3823×600 line 10, `WBT-scribble-line-46.png` 2888×800 line 13, `WBT-scribble-line-47.png` 2511×600 line 12, `WBT-scribble-line-48.png` 2805×600 line 11, `WBT-scribble-line-49.png` 4592×700, `WBT-scribble-line-50.png` 4095×600 line 9

### Scribbles/Loops/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Loops/ (add the file name, spaces as %20)

`WBT-scribble-cascading-ovals.png` 1920×1080 ink 19–73%×11–70% line 8, `WBT-scribble-double-oval-tail.png` 1920×1080 ink 62–97%×14–88% line 14, `WBT-scribble-loop-wavy-tail.png` 1920×1080 ink 18–90%×36–72% line 6, `WBT-scribble-overlapping-ovals.png` 1920×1080 ink 25–92%×20–98% line 9

### Scribbles/Misc/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Misc/ (add the file name, spaces as %20)

`WBT-scribble-misc-01.png` 4204×800, `WBT-scribble-misc-02.png` 4396×1500, `WBT-scribble-misc-03.png` 3342×1100, `WBT-scribble-misc-04.png` 3473×1600, `WBT-scribble-misc-05.png` 2080×700 line 27, `WBT-scribble-misc-06.png` 2156×1900, `WBT-scribble-misc-07.png` 4112×2500, `WBT-scribble-misc-08.png` 2737×1600, `WBT-scribble-misc-09.png` 2879×1700, `WBT-scribble-misc-10.png` 2627×2000, `WBT-scribble-misc-11.png` 1285×750 line 23, `WBT-scribble-misc-12.png` 1500×1173 line 24, `WBT-scribble-misc-13.png` 1226×2000, `WBT-scribble-misc-14.png` 1038×1600 ink 8–94%×1–99% line 39, `WBT-scribble-misc-15.png` 3463×1300, `WBT-scribble-misc-16.png` 4379×1000, `WBT-scribble-misc-17.png` 4181×1000, `WBT-scribble-misc-18.png` 3919×1000, `WBT-scribble-misc-19.png` 3325×2500, `WBT-scribble-misc-20.png` 3914×2500, `WBT-scribble-misc-21.png` 2235×1800, `WBT-scribble-misc-22.png` 1245×600 line 21, `WBT-scribble-misc-23.png` 2852×800, `WBT-scribble-misc-24.png` 6017×1800, `WBT-scribble-misc-25.png` 1951×1000, `WBT-scribble-misc-26.png` 3121×1700, `WBT-scribble-misc-27.png` 2045×2000, `WBT-scribble-misc-28.png` 1814×1800, `WBT-scribble-misc-29.png` 5097×2400, `WBT-scribble-misc-30.png` 3275×1600, `WBT-scribble-misc-31.png` 3920×2100, `WBT-scribble-misc-32.png` 2631×750 line 17, `WBT-scribble-misc-33.png` 2614×750, `WBT-scribble-misc-34.png` 2793×750, `WBT-scribble-misc-35.png` 3216×800, `WBT-scribble-misc-36.png` 2310×1000, `WBT-scribble-misc-37.png` 799×700 line 45, `WBT-scribble-misc-38.png` 2206×2100, `WBT-scribble-misc-39.png` 1636×1500 line 28, `WBT-scribble-misc-40.png` 2806×2600, `WBT-scribble-misc-41.png` 2296×1500, `WBT-scribble-misc-42.png` 1701×1500, `WBT-scribble-misc-43.png` 2402×2500, `WBT-scribble-misc-44.png` 2914×1500, `WBT-scribble-misc-45.png` 2506×2300, `WBT-scribble-misc-46.png` 3092×3000, `WBT-scribble-misc-47.png` 3306×3000, `WBT-scribble-misc-48.png` 3114×3000, `WBT-scribble-misc-49.png` 3818×3500, `WBT-scribble-misc-50.png` 3998×3500

### Scribbles/Ornamental/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Ornamental/ (add the file name, spaces as %20)

`WBT-scribble-ornamental-01.png` 3500×534 line 16, `WBT-scribble-ornamental-02.png` 5028×700, `WBT-scribble-ornamental-03.png` 4000×211 ink 0–100%×24–95% line 16, `WBT-scribble-ornamental-04.png` 4000×264 line 15, `WBT-scribble-ornamental-05.png` 3500×287 ink 0–100%×3–91% line 16, `WBT-scribble-ornamental-06.png` 4000×433 ink 0–100%×11–98% line 20, `WBT-scribble-ornamental-07.png` 4000×292 line 17, `WBT-scribble-ornamental-08.png` 4000×299 line 22, `WBT-scribble-ornamental-09.png` 3800×273 line 14, `WBT-scribble-ornamental-10.png` 3600×223 line 14, `WBT-scribble-ornamental-11.png` 3000×221 line 26, `WBT-scribble-ornamental-12.png` 3000×261 line 30, `WBT-scribble-ornamental-13.png` 4529×400 ink 0–100%×9–90%, `WBT-scribble-ornamental-14.png` 3000×184 ink 0–100%×5–95% line 20, `WBT-scribble-ornamental-15.png` 3000×321 ink 0–100%×3–90% line 16, `WBT-scribble-ornamental-16.png` 2000×217 line 16, `WBT-scribble-ornamental-17.png` 4300×384 line 10, `WBT-scribble-ornamental-18.png` 4500×504 line 9, `WBT-scribble-ornamental-19.png` 4000×304 line 12, `WBT-scribble-ornamental-20.png` 4000×425 line 43, `WBT-scribble-ornamental-21.png` 4000×375 line 48, `WBT-scribble-ornamental-22.png` 2410×500 line 12, `WBT-scribble-ornamental-23.png` 6000×548 ink 1–99%×10–99%, `WBT-scribble-ornamental-24.png` 3500×357 line 16, `WBT-scribble-ornamental-25.png` 2500×424 line 24, `WBT-scribble-ornamental-26.png` 2590×500 ink 0–98%×2–90% line 44, `WBT-scribble-ornamental-27.png` 7414×300 line 9, `WBT-scribble-ornamental-28.png` 6836×400 line 8, `WBT-scribble-ornamental-29.png` 7203×300 ink 0–100%×10–97% line 7, `WBT-scribble-ornamental-30.png` 6543×600 ink 0–100%×17–98% line 8

### Scribbles/Straight/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Straight/ (add the file name, spaces as %20)

`WBT-scribble-straight-01.png` 1500×204 ink 2–98%×12–88% line 116, `WBT-scribble-straight-02.png` 1500×181 ink 1–99%×8–92% line 83, `WBT-scribble-straight-03.png` 1500×94 ink 1–99%×14–85% line 46, `WBT-scribble-straight-04.png` 1500×110 ink 1–99%×14–87% line 67, `WBT-scribble-straight-05.png` 1500×145 ink 1–99%×8–92% line 46, `WBT-scribble-straight-06.png` 2500×109 ink 4–100%×10–90% line 26, `WBT-scribble-straight-07.png` 2500×70 ink 0–100%×14–84% line 24, `WBT-scribble-straight-08.png` 2500×93 ink 0–100%×13–88% line 22, `WBT-scribble-straight-09.png` 2659×170 ink 0–100%×12–82% line 14, `WBT-scribble-straight-10.png` 2839×150 ink 0–100%×18–59% line 15, `WBT-scribble-straight-11.png` 3531×140 ink 0–100%×27–73% line 12, `WBT-scribble-straight-12.png` 2866×100 ink 1–100%×11–89% line 16, `WBT-scribble-straight-13.png` 2175×100 ink 1–100%×15–86% line 20, `WBT-scribble-straight-14.png` 1895×100 ink 1–99%×26–73% line 25, `WBT-scribble-straight-15.png` 6000×192 ink 0–100%×17–96% line 8, `WBT-scribble-straight-16.png` 5899×200 ink 0–100%×48–92% line 7, `WBT-scribble-straight-17.png` 5646×150 ink 0–100%×8–82% line 7, `WBT-scribble-straight-18.png` 7510×150 ink 0–100%×13–90% line 7, `WBT-scribble-straight-19.png` 5034×150 ink 0–99%×8–89% line 10, `WBT-scribble-straight-20.png` 5436×150 ink 0–100%×7–93% line 9, `WBT-scribble-straight-21.png` 6115×300 ink 0–100%×4–89% line 6, `WBT-scribble-straight-22.png` 10006×300 ink 0–100%×37–81% line 5, `WBT-scribble-straight-23.png` 5574×160 ink 0–100%×11–92% line 7, `WBT-scribble-straight-24.png` 6082×130 ink 0–100%×8–92% line 5, `WBT-scribble-straight-25.png` 4649×150 ink 1–100%×7–95% line 7, `WBT-scribble-underline-01.png` 3300×511 ink 0–100%×1–89% line 10, `WBT-scribble-underline-02.png` 5000×689 ink 0–100%×7–89% line 7, `WBT-scribble-underline-03.png` 3500×648 line 10, `WBT-scribble-underline-04.png` 3500×563 line 10, `WBT-scribble-underline-05.png` 3300×704 ink 0–100%×6–94% line 12, `WBT-scribble-underline-06.png` 2300×850 ink 0–100%×9–99% line 17, `WBT-scribble-underline-07.png` 2858×400 ink 1–99%×16–93% line 13, `WBT-scribble-underline-08.png` 5398×600 ink 0–100%×2–85%, `WBT-scribble-underline-09.png` 3200×366 ink 0–100%×5–93% line 12, `WBT-scribble-underline-10.png` 2300×350 ink 0–100%×9–85% line 15, `WBT-scribble-underline-11.png` 4548×350 line 7, `WBT-scribble-underline-12.png` 3500×366 ink 0–95%×11–78% line 10, `WBT-scribble-underline-13.png` 4395×750, `WBT-scribble-underline-14.png` 6127×800, `WBT-scribble-underline-15.png` 5294×500, `WBT-scribble-underline-16.png` 6918×700 ink 0–100%×6–93%, `WBT-scribble-underline-17.png` 5319×500, `WBT-scribble-underline-18.png` 2600×180 ink 0–100%×7–94% line 26, `WBT-scribble-underline-19.png` 2500×130 ink 0–100%×8–92% line 24, `WBT-scribble-underline-20.png` 2516×200 ink 0–100%×6–94% line 18, `WBT-scribble-underline-21.png` 3066×250 ink 0–100%×16–96% line 11, `WBT-scribble-underline-22.png` 5125×500 ink 0–100%×30–98% line 6, `WBT-scribble-underline-23.png` 4323×250 ink 0–100%×4–64% line 11, `WBT-scribble-underline-24.png` 2700×119 ink 0–100%×8–92% line 13, `WBT-scribble-underline-25.png` 4500×151 ink 0–100%×7–93% line 13, `WBT-scribble-underline-26.png` 2300×110 ink 0–100%×10–90% line 25, `WBT-scribble-underline-27.png` 4855×300 line 7, `WBT-scribble-underline-28.png` 4058×300 line 8, `WBT-scribble-underline-29.png` 5492×500 line 9, `WBT-scribble-underline-30.png` 5031×300 line 6, `WBT-scribble-underline-31.png` 4797×250 line 8, `WBT-scribble-underline-32.png` 5035×350 ink 1–100%×14–94% line 7, `WBT-scribble-underline-33.png` 5753×300 ink 0–100%×35–83% line 10, `WBT-scribble-underline-34.png` 5141×400 ink 0–100%×24–97% line 5, `WBT-scribble-underline-35.png` 4727×300 line 9

### Scribbles/Sweeps/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Sweeps/ (add the file name, spaces as %20)

`WBT-scribble-long-sweep-spiral.png` 1920×1080 ink 14–91%×59–81% line 10, `WBT-scribble-s-curve-loop.png` 1920×1080 ink 4–42%×5–85% line 16

### Scribbles/Waves/

Folder URL: https://brand.wbt.coach/assets/Scribbles/Waves/ (add the file name, spaces as %20)

`WBT-scribble-looping-wave.png` 1920×1080 ink 15–85%×14–76% line 9

## Illustrations (102)

Concept illustrations, the top collage layer. Pick by concept (moon = leadership, bees = teams, lightbulb = facilitation).

### Illustrations/

Folder URL: https://brand.wbt.coach/assets/Illustrations/ (add the file name, spaces as %20)

`Agenda.png` 1200×1200 ink 19–77%×9–90%, `Armillary.png` 1200×1200 ink 20–84%×15–90%, `Assessment-4.png` 1200×1200 ink 23–78%×11–89%, `Assessment.png` 1200×1200 ink 21–79%×10–90%, `Bee-Single.png` 1080×1080 ink 68–91%×58–89%, `Bees-Pair.png` 1080×1080 ink 15–87%×20–83%, `Bees-Trio.png` 1080×1080 ink 22–66%×22–73%, `Blue-Blob.png` 1024×1024 ink 25–70%×6–95%, `Brainstorm.png` 1200×1200 ink 26–74%×10–90%, `Brainstorming-2.png` 1200×1200 ink 20–85%×12–90%, `Break.png` 1200×1200 ink 10–92%×14–79%, `Cairn-2.png` 1200×1200 ink 28–75%×12–82%, `Cairn.png` 1200×1200 ink 22–76%×16–82%, `Case-Study-2.png` 1200×1200 ink 38–62%×10–90%, `Case-Study-3.png` 1200×1200 ink 21–79%×7–93%, `Collaboration-3.png` 1200×1200 ink 10–90%×11–89%, `Collaboration.png` 1200×1200 ink 14–88%×13–87%, `Communication-2.png` 1200×1200 ink 21–81%×31–68%, `Communication.png` 1200×1200, `Concept-Noodles.png` 1200×1200 ink 21–79%×10–90%, `Conflict-Management-2.png` 1200×1200 ink 10–90%×16–84%, `Conflict-Management.png` 1200×1200 ink 19–83%×22–76%, `Difficult-Conversations-2.png` 1200×1200 ink 18–82%×10–90%, `Difficult-Conversations.png` 1200×1200 ink 10–90%×15–79%, `Emotional-Intelligence-1.png` 1200×1200 ink 10–92%×10–85%, `Extra-39.png` 1200×1200 ink 10–90%×25–75%, `Eye-Rays.png` 2513×2359 ink 4–93%×5–97%, `Eye.png` 2567×2100, `Feedback-Contact.png` 1200×1200 ink 15–86%×24–69%, `Feedback.png` 1200×1200 ink 29–65%×7–91%, `Full-Moon.png` 705×698, `Fusebox.png` 1200×1200 ink 31–73%×16–85%, `Gold-Blue-Eye.png` 1816×1174 ink 4–93%×10–93%, `Growth-And-Development-1.png` 1200×1200 ink 34–66%×10–90%, `Growth-And-Development-2.png` 1200×1200 ink 14–86%×20–80%, `Hands-With-Eyes.png` 3024×4032 ink 3–91%×16–97%, `Heart-1.png` 1200×1200 ink 17–83%×23–81%, `Heart-2.png` 1200×1200 ink 16–84%×10–90%, `Heart-3.png` 1200×1200 ink 18–79%×1–94%, `Heart-Tablet.png` 2878×3498 ink 7–93%×6–95%, `Heart.png` 2631×2406 ink 8–98%×5–96%, `Horsebell.png` 1200×1200 ink 33–74%×23–82%, `Hourglass.png` 2146×3324 ink 8–89%×7–95%, `Key.png` 3024×1041 ink 9–88%×3–94%, `Leadership-2.png` 1200×1200 ink 10–90%×10–90%, `Leadership-3.png` 1200×1200 ink 19–81%×10–90%, `Leadership.png` 1200×1200 ink 25–75%×17–83%, `Lightbulb-3D.png` 1080×1080 ink 29–71%×13–87%, `Lightbulb-Glowing.png` 1080×1080 ink 19–77%×7–92%, `Lightbulb-Pendant.png` 1080×1080 ink 36–59%×5–92%, `Lunch.png` 1200×1200 ink 12–90%×24–72%, `Managing-Up.png` 1200×1200 ink 11–90%×21–80%, `Map.png` 3024×3339 ink 4–93%×3–96%, `Mirror.png` 896×1810, `Motivation-2.png` 1200×1200 ink 24–73%×11–84%, `Motivation.png` 1200×1200 ink 14–84%×20–86%, `Nest-Bird.png` 2550×2517 ink 5–92%×5–93%, `Nest.png` 2316×2381, `Open-Doors.png` 2780×2982 ink 9–94%×7–97%, `Perception-And-Bias.png` 1200×1200 ink 14–87%×8–84%, `Pink-Blob.png` 1024×1024 ink 17–82%×8–90%, `Pink-Torn-Paper-1.png` 3339×1069, `Pink-Torn-Paper-2.png` 3563×944 ink 1–99%×5–94%, `Planet-Mars.png` 1080×1080 ink 10–90%×10–90%, `Planet-Neptune.png` 1080×1080 ink 10–90%×10–90%, `Psychological-Safety-2.png` 1200×1200 ink 25–74%×14–90%, `Psychological-Safety-3.png` 1200×1200 ink 10–86%×6–85%, `Psychological-Safety-4.png` 1200×1200 ink 24–76%×10–90%, `Psychological-Safety.png` 1200×1200 ink 10–90%×10–90%, `Rays.png` 2000×1373, `Red-Butterfly.png` 2849×2407 ink 7–93%×15–92%, `Reflection-2.png` 1200×1200 ink 14–86%×10–90%, `Reflection.png` 1200×1200 ink 35–65%×14–87%, `Renewal.png` 1200×1200 ink 18–85%×25–81%, `Resilience-Team-2.png` 1200×1200 ink 27–79%×10–82%, `Resilience-Team.png` 1200×1200 ink 20–73%×9–88%, `Resilience.png` 1200×1200 ink 10–86%×28–81%, `Resource-2.png` 1200×1200 ink 11–88%×17–78%, `Resource.png` 1200×1200 ink 10–90%×23–74%, `Roots.png` 2023×2146 ink 5–90%×3–94%, `Saturn-Rings.png` 1080×1080 ink 2–98%×21–79%, `Small-Group-Breakouts.png` 1200×1200 ink 20–84%×15–90%, `Spring.png` 1200×1200 ink 32–69%×14–85%, `Star-Colors.png` 3024×2832 ink 11–87%×4–93%, `Star.png` 2582×2542 ink 8–91%×6–97%, `Street-Lamp.png` 1080×1080 ink 33–63%×3–97%, `Stress-1.png` 1200×1200 ink 24–77%×17–86%, `Stress-2.png` 1200×1200 ink 22–79%×22–79%, `Stress-3.png` 1200×1200 ink 0–100%×30–60%, `Sun.png` 2140×2221 ink 9–94%×7–93%, `Sun2.png` 1981×1786 ink 7–95%×4–93%, `Sundial.png` 1200×1200 ink 5–93%×7–89%, `Tandem-Bicycle.png` 1200×1200 ink 4–95%×26–68%, `Target.png` 1200×1200 ink 13–85%×14–86%, `Team-Cohesion-2.png` 1200×1200 ink 10–75%×15–85%, `Team-Spotlight.png` 1200×1200 ink 18–82%×10–90%, `Telegraph.png` 1200×1200 ink 16–87%×15–84%, `Thank-You.png` 1200×1200 ink 26–76%×26–76%, `Tree-Roots.png` 2466×2880, `Watch.png` 2438×2758 ink 9–82%×5–92%, `Welcome.png` 1200×1200 ink 27–73%×10–90%, `Windmill.png` 1200×1200 ink 9–81%×9–95%

## Shapes (406)

Cut-paper and hand-drawn shapes.

### Shapes/Arrows/

Folder URL: https://brand.wbt.coach/assets/Shapes/Arrows/ (add the file name, spaces as %20)

`WBT-shape-arrow-01.png` 3066×250, `WBT-shape-arrow-02.png` 2668×300, `WBT-shape-arrow-03.png` 6759×400, `WBT-shape-arrow-04.png` 7430×300, `WBT-shape-arrow-05.png` 4597×350, `WBT-shape-arrow-06.png` 6440×600, `WBT-shape-arrow-07.png` 1518×300, `WBT-shape-arrow-08.png` 1486×250, `WBT-shape-arrow-09.png` 3056×500, `WBT-shape-arrow-10.png` 3475×400, `WBT-shape-arrow-11.png` 1455×250, `WBT-shape-arrow-12.png` 3161×300, `WBT-shape-arrow-13.png` 4094×350, `WBT-shape-arrow-14.png` 4290×250, `WBT-shape-arrow-15.png` 3502×450, `WBT-shape-arrow-16.png` 3774×300, `WBT-shape-arrow-17.png` 2749×400, `WBT-shape-arrow-18.png` 6443×500, `WBT-shape-arrow-19.png` 2406×900 ink 0–100%×1–89%, `WBT-shape-arrow-20.png` 4482×600, `WBT-shape-arrow-21.png` 4225×2000, `WBT-shape-arrow-22.png` 3537×600, `WBT-shape-arrow-23.png` 2279×350, `WBT-shape-arrow-24.png` 2531×450 ink 0–100%×3–79%, `WBT-shape-arrow-25.png` 420×1300, `WBT-shape-arrow-26.png` 1344×400, `WBT-shape-arrow-27.png` 1877×500, `WBT-shape-arrow-28.png` 1160×400 ink 1–99%×18–97%, `WBT-shape-arrow-29.png` 2008×600, `WBT-shape-arrow-30.png` 1843×400, `WBT-shape-arrow-31.png` 1533×1300 ink 5–95%×10–94%, `WBT-shape-arrow-32.png` 2193×450, `WBT-shape-arrow-33.png` 1192×250 ink 1–99%×9–96%, `WBT-shape-arrow-34.png` 2165×603 ink 1–99%×5–93%, `WBT-shape-arrow-35.png` 1510×500 ink 1–99%×2–91%, `WBT-shape-arrow-36.png` 1522×350, `WBT-shape-arrow-37.png` 1541×500, `WBT-shape-arrow-38.png` 1173×500, `WBT-shape-arrow-39.png` 1337×300, `WBT-shape-arrow-40.png` 2500×1459 ink 4–97%×7–93%, `WBT-shape-arrow-41.png` 1900×500, `WBT-shape-arrow-42.png` 1719×350, `WBT-shape-arrow-43.png` 1044×500 ink 10–99%×10–98%, `WBT-shape-arrow-44.png` 953×600, `WBT-shape-arrow-45.png` 1000×984 ink 7–91%×10–88%, `WBT-shape-arrow-46.png` 715×850, `WBT-shape-arrow-47.png` 1627×900, `WBT-shape-arrow-48.png` 1400×877, `WBT-shape-arrow-49.png` 1185×761, `WBT-shape-arrow-50.png` 1800×3394, `WBT-shape-arrow-51.png` 2812×1200, `WBT-shape-arrow-52.png` 4159×3500 ink 3–98%×6–93%, `WBT-shape-arrow-53.png` 1125×1000, `WBT-shape-arrow-54.png` 1285×1000, `WBT-shape-arrow-55.png` 2079×2000, `WBT-shape-arrow-56.png` 2250×2000, `WBT-shape-arrow-57.png` 2491×500, `WBT-shape-arrow-58.png` 2069×400, `WBT-shape-arrow-59.png` 4795×1000, `WBT-shape-arrow-60.png` 2750×500, `WBT-shape-arrow-61.png` 2443×1100, `WBT-shape-arrow-62.png` 2893×600, `WBT-shape-arrow-63.png` 2087×1000, `WBT-shape-arrow-64.png` 3660×1200, `WBT-shape-arrow-65.png` 4038×1200, `WBT-shape-arrow-66.png` 1639×700, `WBT-shape-arrow-67.png` 2801×1200, `WBT-shape-arrow-68.png` 627×1300, `WBT-shape-arrow-69.png` 1022×1100 ink 5–99%×11–99%, `WBT-shape-arrow-70.png` 400×415 ink 8–96%×12–93%

### Shapes/Basic/

Folder URL: https://brand.wbt.coach/assets/Shapes/Basic/ (add the file name, spaces as %20)

`WBT-shape-basic-01.png` 637×600, `WBT-shape-basic-02.png` 1170×900, `WBT-shape-basic-03.png` 733×700, `WBT-shape-basic-04.png` 806×900, `WBT-shape-basic-05.png` 947×1000, `WBT-shape-basic-06.png` 895×900, `WBT-shape-basic-07.png` 842×700, `WBT-shape-basic-08.png` 1036×1200, `WBT-shape-basic-09.png` 854×1000, `WBT-shape-basic-10.png` 2125×2000, `WBT-shape-basic-11.png` 1063×1300 ink 5–99%×7–92%, `WBT-shape-basic-12.png` 1382×1300, `WBT-shape-basic-13.png` 1298×1300, `WBT-shape-basic-14.png` 1206×1600, `WBT-shape-basic-15.png` 1465×3000, `WBT-shape-basic-16.png` 579×1000, `WBT-shape-basic-17.png` 1638×2700, `WBT-shape-basic-18.png` 1132×1800, `WBT-shape-basic-19.png` 877×1700, `WBT-shape-basic-20.png` 826×1500, `WBT-shape-basic-21.png` 1072×2000, `WBT-shape-basic-22.png` 757×1300, `WBT-shape-basic-23.png` 2015×2800, `WBT-shape-basic-24.png` 1201×1000, `WBT-shape-basic-25.png` 1001×1000, `WBT-shape-basic-26.png` 1018×1000, `WBT-shape-basic-27.png` 1446×1400, `WBT-shape-basic-28.png` 1527×1300, `WBT-shape-basic-29.png` 983×1000, `WBT-shape-basic-30.png` 1675×1500, `WBT-shape-basic-31.png` 1601×1600, `WBT-shape-basic-32.png` 1133×1000, `WBT-shape-basic-33.png` 1240×1200, `WBT-shape-basic-34.png` 2576×2500, `WBT-shape-basic-35.png` 787×740, `WBT-shape-basic-36.png` 1683×1000, `WBT-shape-basic-37.png` 995×1100, `WBT-shape-basic-38.png` 1524×1500, `WBT-shape-basic-39.png` 1855×1800, `WBT-shape-basic-40.png` 2377×1500, `WBT-shape-basic-41.png` 1521×1200, `WBT-shape-basic-42.png` 1835×1500, `WBT-shape-basic-43.png` 1412×1500, `WBT-shape-basic-44.png` 1668×1200, `WBT-shape-basic-45.png` 1327×1300

### Shapes/Bursts/

Folder URL: https://brand.wbt.coach/assets/Shapes/Bursts/ (add the file name, spaces as %20)

`WBT-shape-burst-01.png` 2842×2500, `WBT-shape-burst-02.png` 1697×1300, `WBT-shape-burst-03.png` 2352×2300, `WBT-shape-burst-04.png` 2600×2577, `WBT-shape-burst-05.png` 2600×4761, `WBT-shape-burst-06.png` 2300×4560, `WBT-shape-burst-07.png` 5000×4799, `WBT-shape-burst-08.png` 1489×1500, `WBT-shape-burst-09.png` 1784×1200, `WBT-shape-burst-10.png` 1271×900, `WBT-shape-burst-11.png` 1298×1000, `WBT-shape-burst-12.png` 1847×2300, `WBT-shape-burst-13.png` 573×800, `WBT-shape-burst-14.png` 2451×1700, `WBT-shape-burst-15.png` 533×600, `WBT-shape-burst-16.png` 1285×700, `WBT-shape-burst-17.png` 1334×1000, `WBT-shape-burst-18.png` 2250×2600

### Shapes/Crosses/

Folder URL: https://brand.wbt.coach/assets/Shapes/Crosses/ (add the file name, spaces as %20)

`WBT-shape-cross-01.png` 910×400, `WBT-shape-cross-02.png` 846×1000, `WBT-shape-cross-03.png` 1800×2145, `WBT-shape-cross-04.png` 1500×1400, `WBT-shape-cross-05.png` 658×700, `WBT-shape-cross-06.png` 966×1350, `WBT-shape-cross-07.png` 983×900, `WBT-shape-cross-08.png` 1020×1000 ink 4–93%×3–96%, `WBT-shape-cross-09.png` 1081×1000, `WBT-shape-cross-10.png` 1312×1000, `WBT-shape-cross-11.png` 755×1200, `WBT-shape-cross-12.png` 463×800, `WBT-shape-cross-13.png` 473×800, `WBT-shape-cross-14.png` 578×800, `WBT-shape-cross-15.png` 450×1000, `WBT-shape-cross-16.png` 402×800 ink 10–97%×1–96%, `WBT-shape-cross-17.png` 402×500 ink 28–98%×2–98%, `WBT-shape-cross-18.png` 960×1600, `WBT-shape-cross-19.png` 837×1300 ink 1–91%×1–99%, `WBT-shape-cross-20.png` 824×1100

### Shapes/Face/

Folder URL: https://brand.wbt.coach/assets/Shapes/Face/ (add the file name, spaces as %20)

`WBT-shape-face-01.png` 568×600, `WBT-shape-face-02.png` 462×1300, `WBT-shape-face-03.png` 1100×923, `WBT-shape-face-04.png` 338×900 ink 15–99%×3–99%, `WBT-shape-face-05.png` 418×800, `WBT-shape-face-06.png` 607×800 ink 7–93%×4–94%, `WBT-shape-face-07.png` 370×500, `WBT-shape-face-08.png` 430×400, `WBT-shape-face-09.png` 326×300, `WBT-shape-face-10.png` 369×1300, `WBT-shape-face-11.png` 883×500, `WBT-shape-face-12.png` 1400×863, `WBT-shape-face-13.png` 1150×1000, `WBT-shape-face-14.png` 1284×800, `WBT-shape-face-15.png` 1082×900, `WBT-shape-face-16.png` 1055×1200, `WBT-shape-face-17.png` 1336×500, `WBT-shape-face-18.png` 1726×800 ink 4–97%×7–90%, `WBT-shape-face-19.png` 600×411, `WBT-shape-face-20.png` 945×600, `WBT-shape-face-21.png` 1620×1000, `WBT-shape-face-22.png` 900×255 ink 0–100%×8–93%, `WBT-shape-face-23.png` 786×500, `WBT-shape-face-24.png` 589×800, `WBT-shape-face-25.png` 2000×1094 ink 3–96%×7–96%, `WBT-shape-face-26.png` 2340×1000, `WBT-shape-face-27.png` 1044×1300, `WBT-shape-face-28.png` 1035×1500, `WBT-shape-face-29.png` 1521×2000, `WBT-shape-face-30.png` 1000×1462, `WBT-shape-face-31.png` 707×800, `WBT-shape-face-32.png` 972×1500, `WBT-shape-face-33.png` 886×1300, `WBT-shape-face-34.png` 854×1300, `WBT-shape-face-35.png` 1275×700, `WBT-shape-face-36.png` 1026×700, `WBT-shape-face-37.png` 1171×500, `WBT-shape-face-38.png` 1405×500, `WBT-shape-face-39.png` 2409×700, `WBT-shape-face-40.png` 2171×700, `WBT-shape-face-41.png` 2366×500, `WBT-shape-face-42.png` 1499×500 ink 3–98%×12–79%, `WBT-shape-face-43.png` 1927×900 ink 4–93%×8–91%, `WBT-shape-face-44.png` 3629×700 ink 0–100%×14–98%, `WBT-shape-face-45.png` 1294×400, `WBT-shape-face-46.png` 1153×400, `WBT-shape-face-47.png` 2710×800, `WBT-shape-face-48.png` 1203×600 ink 4–98%×8–94%, `WBT-shape-face-49.png` 1000×838, `WBT-shape-face-50.png` 1071×1300 ink 9–89%×5–94%, `WBT-shape-face-51.png` 450×655, `WBT-shape-face-52.png` 826×350, `WBT-shape-face-53.png` 790×1000, `WBT-shape-face-54.png` 1000×588 ink 4–96%×7–92%, `WBT-shape-face-55.png` 489×1200, `WBT-shape-face-56.png` 2710×1500, `WBT-shape-face-57.png` 833×500, `WBT-shape-face-58.png` 1423×1000 ink 5–93%×12–85%, `WBT-shape-face-59.png` 1849×1000 ink 4–90%×14–91%, `WBT-shape-face-60.png` 2498×1000, `WBT-shape-face-61.png` 1100×557, `WBT-shape-face-62.png` 2364×1100, `WBT-shape-face-63.png` 3149×1200, `WBT-shape-face-64.png` 1200×489 ink 4–97%×9–92%, `WBT-shape-face-65.png` 388×900, `WBT-shape-face-66.png` 230×500, `WBT-shape-face-67.png` 2160×500, `WBT-shape-face-68.png` 2570×500, `WBT-shape-face-69.png` 1883×900 ink 7–94%×7–87%, `WBT-shape-face-70.png` 1555×450

### Shapes/Hearts/

Folder URL: https://brand.wbt.coach/assets/Shapes/Hearts/ (add the file name, spaces as %20)

`WBT-shape-heart-01.png` 550×1000, `WBT-shape-heart-02.png` 672×1100, `WBT-shape-heart-03.png` 727×1200, `WBT-shape-heart-04.png` 567×1000, `WBT-shape-heart-05.png` 489×1200, `WBT-shape-heart-06.png` 738×1200, `WBT-shape-heart-07.png` 690×900, `WBT-shape-heart-08.png` 675×1200, `WBT-shape-heart-09.png` 610×1200 ink 2–90%×3–99%, `WBT-shape-heart-10.png` 593×1200, `WBT-shape-heart-11.png` 599×600, `WBT-shape-heart-12.png` 910×1200, `WBT-shape-heart-13.png` 1060×1200, `WBT-shape-heart-14.png` 604×1000, `WBT-shape-heart-15.png` 730×900, `WBT-shape-heart-16.png` 1080×1000 ink 11–92%×1–99%, `WBT-shape-heart-17.png` 1038×1200, `WBT-shape-heart-18.png` 1252×700, `WBT-shape-heart-19.png` 1236×1400, `WBT-shape-heart-20.png` 676×1000

### Shapes/Misc/

Folder URL: https://brand.wbt.coach/assets/Shapes/Misc/ (add the file name, spaces as %20)

`WBT-shape-misc-01.png` 700×704, `WBT-shape-misc-02.png` 781×900, `WBT-shape-misc-03.png` 1113×1200 ink 1–99%×10–99%, `WBT-shape-misc-04.png` 1500×1300, `WBT-shape-misc-05.png` 2572×2000, `WBT-shape-misc-06.png` 2450×2500, `WBT-shape-misc-07.png` 2354×1700 ink 0–90%×1–92%, `WBT-shape-misc-08.png` 1175×1500, `WBT-shape-misc-09.png` 600×602, `WBT-shape-misc-10.png` 800×901, `WBT-shape-misc-11.png` 1560×1000, `WBT-shape-misc-12.png` 2679×900, `WBT-shape-misc-13.png` 1914×1500, `WBT-shape-misc-14.png` 3917×1400 ink 3–100%×6–93%, `WBT-shape-misc-15.png` 1812×1800, `WBT-shape-misc-16.png` 900×778, `WBT-shape-misc-17.png` 600×700, `WBT-shape-misc-18.png` 1100×649, `WBT-shape-misc-19.png` 896×1000, `WBT-shape-misc-20.png` 1184×1500, `WBT-shape-misc-21.png` 1352×1000, `WBT-shape-misc-22.png` 993×1000, `WBT-shape-misc-23.png` 1029×1300 ink 6–95%×2–96%, `WBT-shape-misc-24.png` 1046×1100, `WBT-shape-misc-25.png` 1348×1000, `WBT-shape-misc-26.png` 1175×1000, `WBT-shape-misc-27.png` 686×1100, `WBT-shape-misc-28.png` 1938×1600, `WBT-shape-misc-29.png` 750×753, `WBT-shape-misc-30.png` 821×1500, `WBT-shape-misc-31.png` 558×1000, `WBT-shape-misc-32.png` 600×627, `WBT-shape-misc-33.png` 500×616, `WBT-shape-misc-34.png` 1191×1300 ink 7–92%×1–99%, `WBT-shape-misc-35.png` 640×700, `WBT-shape-misc-36.png` 1200×1152, `WBT-shape-misc-37.png` 1348×1000, `WBT-shape-misc-38.png` 1685×1500, `WBT-shape-misc-39.png` 1200×1327 ink 8–96%×5–95%, `WBT-shape-misc-40.png` 1099×500, `WBT-shape-misc-41.png` 1601×1000, `WBT-shape-misc-42.png` 1012×600 ink 1–99%×10–88%, `WBT-shape-misc-43.png` 1208×1300, `WBT-shape-misc-44.png` 837×900, `WBT-shape-misc-45.png` 1033×1200, `WBT-shape-misc-46.png` 1011×1100, `WBT-shape-misc-47.png` 600×900 ink 7–94%×2–98%, `WBT-shape-misc-48.png` 850×867, `WBT-shape-misc-49.png` 697×1000 ink 2–95%×3–93%, `WBT-shape-misc-50.png` 1268×1000, `WBT-shape-misc-51.png` 1360×1100, `WBT-shape-misc-52.png` 900×1024, `WBT-shape-misc-53.png` 800×857, `WBT-shape-misc-54.png` 1100×1179, `WBT-shape-misc-55.png` 911×1000, `WBT-shape-misc-56.png` 900×963, `WBT-shape-misc-57.png` 693×600, `WBT-shape-misc-58.png` 741×800 ink 6–94%×6–92%, `WBT-shape-misc-59.png` 1700×1693, `WBT-shape-misc-60.png` 2000×1991, `WBT-shape-misc-61.png` 2053×2000, `WBT-shape-misc-62.png` 1501×1700 ink 1–90%×5–99%, `WBT-shape-misc-63.png` 1492×1500, `WBT-shape-misc-64.png` 1879×1900, `WBT-shape-misc-65.png` 1329×1200, `WBT-shape-misc-66.png` 1041×1000, `WBT-shape-misc-67.png` 1210×1300, `WBT-shape-misc-68.png` 778×1600, `WBT-shape-misc-69.png` 1859×800, `WBT-shape-misc-70.png` 2461×1000, `WBT-shape-misc-71.png` 871×1700, `WBT-shape-misc-72.png` 657×1200, `WBT-shape-misc-73.png` 1581×2100, `WBT-shape-misc-74.png` 2619×1300, `WBT-shape-misc-75.png` 739×700 ink 5–97%×4–93%, `WBT-shape-misc-76.png` 1088×1000

### Shapes/Punctuation/

Folder URL: https://brand.wbt.coach/assets/Shapes/Punctuation/ (add the file name, spaces as %20)

`WBT-shape-punctuation-01.png` 971×1000 ink 7–93%×8–92%, `WBT-shape-punctuation-02.png` 1522×1600, `WBT-shape-punctuation-03.png` 1363×1200 ink 1–95%×6–96%, `WBT-shape-punctuation-04.png` 1111×1000, `WBT-shape-punctuation-05.png` 808×850, `WBT-shape-punctuation-06.png` 675×800, `WBT-shape-punctuation-07.png` 652×600, `WBT-shape-punctuation-08.png` 948×1000, `WBT-shape-punctuation-09.png` 1166×1700, `WBT-shape-punctuation-10.png` 785×2000, `WBT-shape-punctuation-11.png` 958×1300, `WBT-shape-punctuation-12.png` 743×1200 ink 7–91%×1–99%, `WBT-shape-punctuation-13.png` 665×1600, `WBT-shape-punctuation-14.png` 370×400 ink 7–93%×6–94%, `WBT-shape-punctuation-15.png` 287×400 ink 8–92%×6–94%, `WBT-shape-punctuation-16.png` 443×800, `WBT-shape-punctuation-17.png` 109×1000 ink 9–91%×1–99%, `WBT-shape-punctuation-18.png` 141×700 ink 6–94%×1–99%, `WBT-shape-punctuation-19.png` 367×1300 ink 10–91%×1–100%, `WBT-shape-punctuation-20.png` 257×1000, `WBT-shape-punctuation-21.png` 386×1600 ink 8–97%×1–99%, `WBT-shape-punctuation-22.png` 747×700, `WBT-shape-punctuation-23.png` 1323×1600, `WBT-shape-punctuation-24.png` 1395×1300, `WBT-shape-punctuation-25.png` 1093×1200, `WBT-shape-punctuation-26.png` 1822×1300, `WBT-shape-punctuation-27.png` 1848×1600, `WBT-shape-punctuation-28.png` 614×800, `WBT-shape-punctuation-29.png` 340×1000, `WBT-shape-punctuation-30.png` 355×1000, `WBT-shape-punctuation-31.png` 686×1500, `WBT-shape-punctuation-32.png` 768×1400, `WBT-shape-punctuation-33.png` 662×1500, `WBT-shape-punctuation-34.png` 600×333, `WBT-shape-punctuation-35.png` 364×500, `WBT-shape-punctuation-36.png` 699×700 ink 15–98%×3–95%

### Shapes/Smileys/

Folder URL: https://brand.wbt.coach/assets/Shapes/Smileys/ (add the file name, spaces as %20)

`WBT-shape-smiley-01.png` 935×1500 ink 12–91%×4–93%, `WBT-shape-smiley-02.png` 1055×1000, `WBT-shape-smiley-03.png` 839×800, `WBT-shape-smiley-04.png` 859×900, `WBT-shape-smiley-05.png` 967×500, `WBT-shape-smiley-06.png` 860×500, `WBT-shape-smiley-07.png` 773×600, `WBT-shape-smiley-08.png` 984×700, `WBT-shape-smiley-09.png` 1146×856, `WBT-shape-smiley-10.png` 1605×962, `WBT-shape-smiley-11.png` 963×800, `WBT-shape-smiley-12.png` 1000×915, `WBT-shape-smiley-13.png` 868×800, `WBT-shape-smiley-14.png` 847×450, `WBT-shape-smiley-15.png` 490×500, `WBT-shape-smiley-16.png` 1087×500, `WBT-shape-smiley-17.png` 790×500 ink 4–98%×2–92%, `WBT-shape-smiley-18.png` 432×500, `WBT-shape-smiley-19.png` 655×500, `WBT-shape-smiley-20.png` 1501×500, `WBT-shape-smiley-21.png` 1605×1078

### Shapes/Stars/

Folder URL: https://brand.wbt.coach/assets/Shapes/Stars/ (add the file name, spaces as %20)

`WBT-shape-star-01.png` 1484×1700 ink 7–92%×6–93%, `WBT-shape-star-02.png` 578×600, `WBT-shape-star-03.png` 1049×1300, `WBT-shape-star-04.png` 898×1300, `WBT-shape-star-05.png` 556×1000, `WBT-shape-star-06.png` 755×1200, `WBT-shape-star-07.png` 1708×1700, `WBT-shape-star-08.png` 1412×1200, `WBT-shape-star-09.png` 1081×1700, `WBT-shape-star-10.png` 1489×1200, `WBT-shape-star-11.png` 724×600, `WBT-shape-star-12.png` 676×700, `WBT-shape-star-13.png` 710×600, `WBT-shape-star-14.png` 1250×1600, `WBT-shape-star-15.png` 1207×1300, `WBT-shape-star-16.png` 1219×1200, `WBT-shape-star-17.png` 853×1000, `WBT-shape-star-18.png` 1047×900 ink 6–95%×7–95%, `WBT-shape-star-19.png` 839×800, `WBT-shape-star-20.png` 1414×1200, `WBT-shape-star-21.png` 1071×900, `WBT-shape-star-22.png` 1011×800, `WBT-shape-star-23.png` 1294×1500, `WBT-shape-star-24.png` 907×1000, `WBT-shape-star-25.png` 917×1000, `WBT-shape-star-26.png` 1563×1500, `WBT-shape-star-27.png` 1040×1200, `WBT-shape-star-28.png` 1444×1600, `WBT-shape-star-29.png` 2552×2300, `WBT-shape-star-30.png` 1447×1200

## Frames (104)

Hand-drawn frames for photos and text.

### Frames/Boxes/

Folder URL: https://brand.wbt.coach/assets/Frames/Boxes/ (add the file name, spaces as %20)

`WBT-frame-box-01.png` 857×1000, `WBT-frame-box-02.png` 1079×1000, `WBT-frame-box-03.png` 2504×2000, `WBT-frame-box-04.png` 4580×1800, `WBT-frame-box-05.png` 4668×1600, `WBT-frame-box-06.png` 3239×3200, `WBT-frame-box-07.png` 3125×3300, `WBT-frame-box-08.png` 3736×3300, `WBT-frame-box-09.png` 3962×3300, `WBT-frame-box-10.png` 1500×1351, `WBT-frame-box-11.png` 1500×1385, `WBT-frame-box-12.png` 2930×2500, `WBT-frame-box-13.png` 2000×2883, `WBT-frame-box-14.png` 2000×4235, `WBT-frame-box-15.png` 962×2500, `WBT-frame-box-16.png` 1124×3600, `WBT-frame-box-17.png` 1991×2400, `WBT-frame-box-18.png` 5212×1300, `WBT-frame-box-19.png` 4709×1100, `WBT-frame-box-20.png` 3672×3728, `WBT-frame-box-21.png` 1800×1795, `WBT-frame-box-22.png` 1886×2000, `WBT-frame-box-23.png` 2000×1945, `WBT-frame-box-24.png` 2629×5000, `WBT-frame-box-25.png` 2547×5000, `WBT-frame-box-26.png` 2037×2600, `WBT-frame-box-27.png` 2367×3700, `WBT-frame-box-28.png` 3000×688, `WBT-frame-box-29.png` 1600×1640, `WBT-frame-box-30.png` 2500×917, `WBT-frame-box-31.png` 2400×2803, `WBT-frame-box-32.png` 3000×2802, `WBT-frame-box-33.png` 3872×3200, `WBT-frame-box-34.png` 4161×2000, `WBT-frame-box-35.png` 6030×3000, `WBT-frame-box-36.png` 5000×657, `WBT-frame-box-37.png` 3043×1000, `WBT-frame-box-38.png` 2429×2000, `WBT-frame-box-39.png` 2500×2133, `WBT-frame-box-40.png` 3008×1400, `WBT-frame-box-41.png` 4340×700, `WBT-frame-box-42.png` 2610×2500, `WBT-frame-box-43.png` 3830×1600, `WBT-frame-box-44.png` 4042×4000, `WBT-frame-box-45.png` 4440×3500, `WBT-frame-box-46.png` 3266×600, `WBT-frame-box-47.png` 4184×600, `WBT-frame-box-48.png` 8115×3200, `WBT-frame-box-49.png` 2364×1400, `WBT-frame-box-50.png` 5553×3500, `WBT-frame-box-51.png` 1281×900, `WBT-frame-box-52.png` 5442×900 ink 0–100%×1–90%, `WBT-frame-box-53.png` 5853×600 ink 0–99%×8–97%, `WBT-frame-box-54.png` 2606×900 ink 1–98%×6–95%, `WBT-frame-box-55.png` 1500×443, `WBT-frame-box-56.png` 2265×2000, `WBT-frame-box-57.png` 3259×3000, `WBT-frame-box-58.png` 4658×4500, `WBT-frame-box-59.png` 1822×1000, `WBT-frame-box-60.png` 4982×2500

### Frames/Circles/

Folder URL: https://brand.wbt.coach/assets/Frames/Circles/ (add the file name, spaces as %20)

`WBT-frame-circle-01.png` 6000×5093, `WBT-frame-circle-02.png` 5000×1455, `WBT-frame-circle-03.png` 6000×628, `WBT-frame-circle-04.png` 5000×1680, `WBT-frame-circle-05.png` 6000×3457, `WBT-frame-circle-06.png` 3834×900 ink 1–100%×2–92%, `WBT-frame-circle-07.png` 2406×2300, `WBT-frame-circle-08.png` 3536×800, `WBT-frame-circle-09.png` 2693×2500, `WBT-frame-circle-10.png` 3158×1000, `WBT-frame-circle-11.png` 4362×900, `WBT-frame-circle-12.png` 3750×1000, `WBT-frame-circle-13.png` 3915×1000, `WBT-frame-circle-14.png` 4021×1400, `WBT-frame-circle-15.png` 2043×1600, `WBT-frame-circle-16.png` 1592×1600, `WBT-frame-circle-17.png` 4588×1300, `WBT-frame-circle-18.png` 1819×1800, `WBT-frame-circle-19.png` 4149×1200, `WBT-frame-circle-20.png` 2400×1900, `WBT-frame-circle-21.png` 3328×1500, `WBT-frame-circle-22.png` 4730×1800, `WBT-frame-circle-23.png` 2930×1800, `WBT-frame-circle-24.png` 3242×1400

### Frames/Speech-Bubbles/

Folder URL: https://brand.wbt.coach/assets/Frames/Speech-Bubbles/ (add the file name, spaces as %20)

`WBT-frame-speech-bubble-01.png` 4500×3296, `WBT-frame-speech-bubble-02.png` 3200×1744, `WBT-frame-speech-bubble-03.png` 3500×2768, `WBT-frame-speech-bubble-04.png` 3000×1714, `WBT-frame-speech-bubble-05.png` 3841×3500, `WBT-frame-speech-bubble-06.png` 2600×1727, `WBT-frame-speech-bubble-07.png` 3808×2000, `WBT-frame-speech-bubble-08.png` 3500×2512, `WBT-frame-speech-bubble-09.png` 2400×2130, `WBT-frame-speech-bubble-10.png` 3180×4000, `WBT-frame-speech-bubble-11.png` 3277×2500, `WBT-frame-speech-bubble-12.png` 3500×2753, `WBT-frame-speech-bubble-13.png` 3000×2310, `WBT-frame-speech-bubble-14.png` 2515×2000, `WBT-frame-speech-bubble-15.png` 3812×3100 ink 16–100%×3–100%, `WBT-frame-speech-bubble-16.png` 3001×1700, `WBT-frame-speech-bubble-17.png` 2904×1700, `WBT-frame-speech-bubble-18.png` 3399×1900, `WBT-frame-speech-bubble-19.png` 2863×2600, `WBT-frame-speech-bubble-20.png` 1000×952 ink 6–91%×4–95%

## Patterns (34)

Repeat patterns and textures.

### Patterns/

Folder URL: https://brand.wbt.coach/assets/Patterns/ (add the file name, spaces as %20)

`WBT-pattern-01.png` 2000×1788, `WBT-pattern-02.png` 2500×2482, `WBT-pattern-04.png` 2500×2304, `WBT-pattern-05.png` 2500×2260, `WBT-pattern-06.png` 2500×2316, `WBT-pattern-07.png` 2500×2339, `WBT-pattern-08.png` 2500×2613, `WBT-pattern-09.png` 2500×2356, `WBT-pattern-10.png` 2500×2369, `WBT-pattern-11.png` 2500×2474, `WBT-pattern-12.png` 2500×2486, `WBT-pattern-13.png` 2500×2548, `WBT-pattern-14.png` 2500×2247, `WBT-pattern-15.png` 2500×2454, `WBT-pattern-16.png` 2500×2377, `WBT-pattern-17.png` 2500×2457, `WBT-pattern-18.png` 2500×2419, `WBT-pattern-19.png` 2500×2232, `WBT-pattern-20.png` 1604×1300, `WBT-pattern-21.png` 1680×1680, `WBT-pattern-22.png` 1577×1400, `WBT-pattern-23.png` 2198×2000 ink 2–98%×6–96%, `WBT-pattern-24.png` 1056×1200, `WBT-pattern-25.png` 1398×1000, `WBT-pattern-26.png` 2658×2300, `WBT-pattern-27.png` 2386×2200, `WBT-pattern-28.png` 2960×3000, `WBT-pattern-29.png` 2575×2300, `WBT-pattern-30.png` 2991×3000, `WBT-pattern-31.png` 2793×2500, `WBT-pattern-32.png` 2724×2300, `WBT-pattern-33.png` 2850×2500, `WBT-pattern-34.png` 2779×2400, `WBT-pattern-35.png` 2600×2554

## Photography (11)

WBT's own photos (founders, sessions). Use as placeholders; never stock.

### Photography/

Folder URL: https://brand.wbt.coach/assets/Photography/ (add the file name, spaces as %20)

`WBT-Courtney-Curd-Smiling.jpg` 4032×3024 (really MPO), `WBT-Eli-Northrup-Candidate.jpg` 4032×3024 (really MPO), `WBT-Jenna-Headshot.jpg` 1329×1500 (really WEBP), `WBT-Jenna-Stacy-Triptych.png` 2000×875, `WBT-Jenna-and-Stacy-Floor.jpg` 2500×1746 (really WEBP), `WBT-Stacy-Headshot.jpg` 1329×1500 (really WEBP), `WBT-jenna-and-stacy-at-window.jpg` 1800×1200 (really WEBP)

### Photography/case-study-duotones/

Folder URL: https://brand.wbt.coach/assets/Photography/case-study-duotones/ (add the file name, spaces as %20)

`campaign-team-retreat-to-align-at-the-start.jpg` 1920×1080 (really WEBP), `coaching-to-support-leadership-development.jpg` 1920×1080, `facilitation-to-prepare-for-uncertainty.jpg` 1920×1080 (really WEBP), `moving-from-stress-to-strategy-with-a-team.jpg` 1920×1080 (really WEBP)

## Finished Collages (9)

Approved collages. Match their density and scale.

### Finished Collages/

Folder URL: https://brand.wbt.coach/assets/Finished%20Collages/ (add the file name, spaces as %20)

`WBT-collage-bees-blue-circle.png` 1080×1080 ink 8–88%×11–84%, `WBT-collage-brain-blue.png` 750×500, `WBT-collage-compass.png` 1080×1080 ink 16–88%×10–86%, `WBT-collage-eyeglasses-eye-chart.png` 750×500 ink 8–88%×7–88%, `WBT-collage-gramophone.png` 1080×1080 ink 11–80%×10–90%, `WBT-collage-lightbulb-orange.png` 1920×1080 ink 20–76%×8–82%, `WBT-collage-megaphone.png` 750×500 ink 6–71%×6–100%, `WBT-collage-moon-gold.png` 1080×1080 ink 10–82%×6–99%, `WBT-collage-rotary-telephone.png` 1080×1080 ink 2–98%×16–90%

## Generated Illustrations (14)

Collages made in the Collage Maker.

### Generated Illustrations/

Folder URL: https://brand.wbt.coach/assets/Generated%20Illustrations/ (add the file name, spaces as %20)

`WBT-collage-empower-training-sessions-20260706.png` 1600×1600 ink 11–88%×0–76%, `WBT-collage-facilitation-training-stacy-marlon-20260507.png` 1600×1600, `WBT-collage-follow-the-camels-20260515.png` 1600×1600, `WBT-collage-gold-moon-20260526.png` 1600×1600, `WBT-collage-i-see-you-20260507.png` 1600×1600, `WBT-collage-julia-testing-20260507.png` 1600×1600, `WBT-collage-light-bulb-test-20260728.png` 1600×1600, `WBT-collage-planet-of-bees-20260506.png` 1600×1600, `WBT-collage-planetary-exploration-20260507.png` 1600×1600 ink 6–99%×14–88%, `WBT-collage-seeing-work-20260506.png` 1600×1600, `WBT-collage-silly-lucas-slop-20260519.png` 1600×1600, `WBT-collage-strategic-innovation-20260506.png` 1600×1600, `WBT-collage-unlock-pathways-20260506.png` 1600×1600 ink 13–88%×9–86%, `WBT-collage-vision-20260709.png` 1600×1600 ink 6–94%×22–72%

## Client Logos (20)

Client logos for "who we work with" rows.

### Client Logos/

Folder URL: https://brand.wbt.coach/assets/Client%20Logos/ (add the file name, spaces as %20)

`WBT-client-logo-adoptions-together.png` 982×470 ink 12–86%×25–76%, `WBT-client-logo-allied-for-progress.png` 976×1172 ink 21–77%×16–89%, `WBT-client-logo-august.png` 982×470 ink 16–84%×26–74%, `WBT-client-logo-basic.png` 976×1172 ink 16–86%×22–83%, `WBT-client-logo-casey-foundation.png` 982×470 ink 17–84%×2–97%, `WBT-client-logo-centennial-state-prosperity.png` 982×470 ink 17–83%×16–85%, `WBT-client-logo-champ.png` 982×470 ink 12–88%×30–69%, `WBT-client-logo-climateworks.png` 982×470 ink 12–88%×31–69%, `WBT-client-logo-dnc.png` 982×470 ink 11–86%×12–86%, `WBT-client-logo-eli-assembly.svg` svg, `WBT-client-logo-emilys-list.png` 982×470 ink 16–84%×19–81%, `WBT-client-logo-empower-project.png` 982×470 ink 9–91%×29–71%, `WBT-client-logo-maryland-childcare-network.png` 982×470 ink 12–88%×33–67%, `WBT-client-logo-maryland-family-network.png` 982×470 ink 13–87%×23–77%, `WBT-client-logo-mtrny.png` 976×1172 ink 13–84%×10–91%, `WBT-client-logo-nyc-community-schools.png` 982×470 ink 30–70%×21–79%, `WBT-client-logo-nyc-doe-oswp.png` 982×470 ink 12–86%×24–76%, `WBT-client-logo-pivot.png` 982×470 ink 14–86%×23–77%, `WBT-client-logo-pivotal.png` 982×470 ink 13–86%×21–69%, `WBT-client-logo-planned-parenthood-for-america.png` 982×470 ink 13–87%×30–70%

## Swag (8)

Approved merchandise renders.

### Swag/

Folder URL: https://brand.wbt.coach/assets/Swag/ (add the file name, spaces as %20)

`WBT-Black-Pin.png` 1254×1254, `WBT-Blue-Beanie-Closeup.png` 1180×1333, `WBT-Blue-Beanie.png` 1227×1281, `WBT-Blue-Cap.png` 1254×1254, `WBT-Blue-Gold-Pin.png` 1254×1254, `WBT-Pins.png` 1536×1024, `WBT-White-Black-Hat.png` 1268×1241, `WBT-White-Hat.png` 1254×1254
