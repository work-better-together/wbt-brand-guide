# Approved examples and templates

## Examples (`assets/examples/`)

Real WBT work, captured October 2026. Before you hand anything over, open the closest one and compare density, scale and spacing.

| File | What it shows | Match it for |
|---|---|---|
| `01-site-home.jpg` | workbettertogether.coach home: full-bleed founder photo, the tagline as the hero (two centered lines, one bold weight), cream page, Lora intro with a hand-drawn blue circle. | Hero scale, reversed headline over a photo, how sparse the page is. |
| `02-site-leadership.jpg` | Leadership Coaching page: big uppercase feature heading → Lora italic “that…” subhead → League Spartan 400 deck; the moon-and-Saturn collage on gold; ochre eyebrows; gold duotone photo. | The three-weight heading rhythm, the Leadership collage, eyebrow color on light. |
| `03-site-team.jpg` | Team Coaching page: bees on Intentional Blue, a black scribble on the blue panel, blue duotone photo, a Steady Blue panel with cream type. | The Team collage, black scribbles on Intentional Blue, dark panels. |
| `04-newsletter.jpg` | Field Notes email: wordmark, collage header, 46px headline, Lora body, pull quote, blue CTA block. | Email hierarchy and spacing at 600px. |
| `05-deck-template-index.jpg` | The deck template's index of slide layouts (proposals, retreats, workshops). | Slide type scale and the layout names to ask for. |
| `06-worksheet-after-action-review.jpg` | A resources.wbt.coach worksheet: Steady Blue band with the white wordmark top-right, numbered steps of a real sequence, Steady Blue prompt headings in a 2×2 grid, Calm Blue closing row, the tagline small in the footer. | Worksheet density: fill the page, plain and practical, no collages. |
| `07-collage-proportions.jpg` | The five resources.wbt.coach category collages (moon, bees, lightbulb, compass, megaphone). | Collage proportions: the illustration leads, the spot peeks out from behind at about its size, thin scribble loops wrap it. |

The approved collages themselves are in the asset catalog under **Finished Collages**.

## Resources by category (resources.wbt.coach, behind a newsletter sign-up)

Use the category's collage pairing for any piece about a resource.
- **Resources for Leaders** (moon on gold): Values & Energy (interactive values sort + energy map), Feedback Collection Framework (one-page guide), A Thing I'm Hoping to Learn (growth-goal worksheet).
- **Resources for Teams** (bees on Intentional Blue): After Action Review, Role Clarity, Norms, Routines, and Rituals, End-of-Year Review for Teams (two-hour facilitation guide).
- **Retreat Preparation** (lightbulb on ochre): Our approach to team retreats (planning timeline), Thinking about a team retreat? (checklist).
- **Career Transitions** (compass collage): Career Timeline.
- **Campaign Leaders** (megaphone collage): the End-of-Cycle Transition playbook (17 one-page tools, e.g. 2x2 Check-out, Transition Schedule).
Describe a resource only from these notes or text the user gives you; don't invent what it contains.

## Templates (`assets/templates/`)

Start from the closest template and swap content. Change the layout only when the brief needs it. Each file's top comment lists its slots, sizes and word limits. Library art loads from brand.wbt.coach; fonts and logos are bundled.

| Template | Canvas | Use for |
|---|---|---|
| `ig-collage-headline.html` | 1080×1350 | The default post: announcements, services, events. Collage + eyebrow + headline + deck + body + CTA. |
| `ig-quote.html` | 1080×1350 | Testimonials and quotes, on Steady Blue. |
| `ig-stat.html` | 1080×1080 | One key stat, gold on Steady Blue, with its source. |
| `ig-photo-split.html` | 1080×1350 | Only when a photo is supplied or asked for. |
| `story-collage.html` | 1080×1920 | Stories and Reels covers, with the app's safe zones. |
| `linkedin-link.html` | 1200×627 | LinkedIn and Open Graph link images. |
| `worksheet-letter.html` | US Letter | One-page worksheets and handouts. PDF: `bash scripts/render.sh file.html out.pdf --pdf`. |
| `web-hero-service.html` | Web, 1440 + 390 | A service-page hero (the live `.hero-svc` pattern), with the phone layout. |
| `onepager-letter.html` | US Letter | Client one-pagers and service overviews: feature heading, collage off the corner, two columns, a Steady Blue quote + CTA band. PDF must be one page. |
| `email-section.html` | Email, 600px | A newsletter section: collage, eyebrow, headline, body, list, quote, dark CTA band. Table-based, email-safe. |

## Starter deck (`assets/templates/wbt-starter-deck.pptx`)

Eight editable 16:9 slides built from the brand guide's deck template: cover (Calm Blue watercolor), section divider (Steady Blue watercolor, gold spot, scribble), content, photo + text, quote, three stats (the ICF figures from the website), bio, thank you. Theme fonts League Spartan + Lora and the WBT palette are set in the theme, and every slide has a Fade transition (calm, per WBT motion).

- **For a deck request,** copy this file and edit it: duplicate the closest slide, replace its text, swap photos for WBT's own. Don't rebuild slides from scratch. With python-pptx, open the file and copy slides; keep the theme.
- **Google Slides:** File › Import slides (League Spartan and Lora are built in). **PowerPoint / Keynote:** install the fonts in `assets/fonts/` first, or the text falls back.
- Size rules from `formats.md` (Slides): title 36pt (72px), body 14–16pt (28–32px), at most 40 words a slide. Speaker notes on each slide say what to replace.
- For a designed deck delivered as a PDF or web page, the HTML deck template at https://brand.wbt.coach/deck-template/ has 31 layouts.

Render with `bash scripts/render.sh <file.html> <out.png> <width> <height>` (headless Chrome). For a PDF: `bash scripts/render.sh file.html out.pdf --pdf` (Letter, no margins, backgrounds on; it reports the page count).

Every social deliverable ships with a ready-to-paste caption (link in the caption, never on the tile) and alt text.
