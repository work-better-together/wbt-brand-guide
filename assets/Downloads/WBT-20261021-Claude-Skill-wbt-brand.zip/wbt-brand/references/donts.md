# Don't fall back on Claude design tropes

Claude has a house style: the look it reaches for when a brief leaves gaps. It makes everything look like the same AI-made landing page. WBT has its own answer for almost every gap, so use WBT's answer.

This list is calibrated to what WBT actually ships, measured on workbettertogether.coach, tools.wbt.coach and resources.wbt.coach (Oct 2026). If WBT uses a pattern, it is allowed, in WBT's form and in WBT's places. If none of WBT's sites use it, don't add it.

## Allowed, in WBT's form only

| Pattern | How WBT uses it | Don't |
|---|---|---|
| **Eyebrows** | Above section headlines on every site page. League Spartan 500, 14px, +0.16em, uppercase. Honest Ochre on light, Radiant Gold on dark. | Put them in pill chips or boxes, set them in mono, color them blue, or stack one over every small block. One per section. |
| **Arrows** | `→` at the end of a text call to action ("Learn more →", "Open tool →", "Browse →"), Inconsolata 500 uppercase. `↗` only on a link that leaves the site ("Contact us ↗"). | Arrows as bullets, decoration, or inside headlines. No `↗` on internal links. |
| **Pills (9999px)** | Filter chips (Our Work, Tools) and the round carousel arrow buttons. | Pill badges on headings, "New" tags, pills as decoration. Tags are 2px, not pills. |
| **Rounded corners** | Buttons 10px; tags and inputs 2px; small images 4px; the case-study card carousel 16px. | Rounded content cards or panels. Everything else is square (0). |
| **White surfaces** | Dropdown menus, carousel arrow buttons, filter chips, and the tool cards on tools.wbt.coach (white, 1px `#E4E2DE`, square). The page itself is always Clear White `#F9F8F2`. | A pure-white page, or a grid of floating white cards on a gray page. |
| **Shadows** | Soft and wide, only on things that float: the nav dropdown, bio-collage photos, the card carousel. | Shadows on static content, cards, buttons or text. No glows. |
| **Gradients** | Only as the duotone scrim over a photo (blue or ochre, about 60% opacity) so cream type clears contrast. | Decorative gradient backgrounds, gradient text, gradient buttons, mesh or blob gradients. |
| **Centered text** | Statement blocks, quote blocks and service-page heroes. | Centered body paragraphs, centered lists, centering every section. |
| **Icons** | The illustrated icons and illustrations from the library (asset-catalog.md); Lucide (1.5px stroke) only for interface controls in tools. | Icons in colored circles above three feature columns, icons as decoration, any other icon set, emoji as icons. |
| **Hand-drawn marks** | Circles, underlines and waves in Intentional Blue on one or two key phrases per passage (rough-annotation). The gold scratch for an insight. | Highlighter blocks, marker fills, more than two marks a passage. |
| **Stats** | A key stat in Intentional Blue, Radiant Gold or Honest Ochre (by ground, see SKILL.md › Key stats) with a short Lora line. | Rows of three identical stat tiles, animated count-ups, KPI dashboards for non-data content. |

## Never (no WBT site uses these)

- **Boxed text grids** — the most common Claude tell: two, three or four bordered (or white/tinted) boxes, each holding a heading and a paragraph (principles, features, benefits, steps, tips). WBT sets these as **open columns**: a League Spartan heading and Lora text, separated by space or a 1px top rule in `#E4E2DE`, no box. Same for single callout boxes around ordinary text: use type, not a frame. Boxes are only for clickable cards (tools, resources, case studies), form fields, and colored or photo mosaic panels.

- **Emoji** anywhere: copy, bullets, headings, buttons, social tiles. Also no ✓, ★ or ✨ as bullets or decoration.
- **Numbered section labels** (01 / 02 / 03, "Step 01") as decoration. Number only a real sequence, in plain type.
- **Dashed or dotted borders**, dashed callout boxes, "drop zone" boxes.
- **Glassmorphism**, frosted panels, blur behind cards, neon, glows, inner shadows.
- **Recolored scribbles**: white, cream or tinted scribbles. Scribbles are always black; skip them on very dark grounds.
- **Drawn stand-ins for brand devices**: straight rules, bars, plain circles, blobs or squiggles drawn in SVG or CSS where WBT has a real spot, scribble, frame or shape file. Place the file from asset-catalog.md.
- **The generic SaaS page**: gradient hero with a centered headline and two buttons, a logo bar captioned "Trusted by", three feature cards with icons, a pricing-style grid.
- **Placeholder people**: silhouettes, avatars, illustrated personas, stock-photo stand-ins. Use WBT's own photos or leave a labeled empty frame.
- **Pure black `#000` or pure white `#FFF` as a page ground**, gray text for body copy.
- **More than one collage color in one composition.** The system colors don't count against this: ochre or gold eyebrows, Intentional Blue links and CTAs, gold quote marks. Pick one spot color (the service color) and keep everything else in the system roles.
- **Fonts other than League Spartan, Lora and Inconsolata.** No system UI fonts, no Inter, no serif stand-ins for Lora in designed work.

## Copy tropes

- No hype words: elevate, unlock, supercharge, empower (as a verb in a headline), game-changer, seamless, cutting-edge, world-class, journey (for a service), "in today's fast-paced world".
- No urgency or performative warmth ("Act now", "Don't miss out", "We're SO excited").
- No stacked three-adjective lines ("Bold. Brave. Brilliant.") unless WBT wrote them.
- Short, direct, warm sentences, as on workbettertogether.coach. WBT does use the "It isn't X. It's Y." turn ("Emotional intelligence isn't the soft stuff. It's the work."). Keep it for real insights, at most once per piece.

## Before you hand anything over

Look at the rendered output and ask: would this look at home next to a page of workbettertogether.coach? If an element exists only because it "looks designed", take it out.
