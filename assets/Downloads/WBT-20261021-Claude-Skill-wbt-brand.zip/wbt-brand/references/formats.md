# Formats and type sizes

Every size here is measured from WBT's own production files (Oct 2026): the brand guide's Social Card Maker (now the Social page, brand.wbt.coach/social), the deck template, the Field Notes newsletter, the resources.wbt.coach worksheets, and workbettertogether.coach. Social sizes scale with canvas width (W), so the same proportions work on every canvas.

**When in doubt, go bigger. Type that's too small is the most common failure.** Never go below a minimum in this file.

## Social

Margins: **8% of W** on every side (86px on 1080). **Logo: the monogram, bottom-right, 6.5% of W tall** (70px on 1080), inside the margin, in ink on light grounds or Clear White on dark. Use the full wordmark instead only when the post introduces WBT to people who don't know it (an event poster, an ad); then 18% of W wide. Handle in captions and attributions: **@wbtcoaching**. The headline block starts in the top half; leave the bottom 15% for the wordmark and attribution.

| Canvas | Headline (League Spartan 700, lh 1.05) | Subhead / body (Lora 400, lh 1.55) | Attribution / CTA (Inconsolata 500, caps, +0.18em) | Quote (Lora italic) | Stat number (League Spartan 700–800) |
|---|---|---|---|---|---|
| **Instagram portrait 1080×1350** (default for every post and carousel) | **92px** (76 / 64px for longer heads); min 64px | deck **60px**, body 44px, list points 42px; **min 36px** | 26–30px; **min 26px** | 58px (5.4% W); 52px past 24 words | 230–280px |
| **Instagram / LinkedIn square 1080×1080** (default for stat posts) | 89px; min 64px | 38px; **min 36px** | 26px; **min 26px** | 58px | 230px |
| **Story / Reel 1080×1920** | 92–96px; min 64px | deck **64px**, body 50px, list points 46px; min 38px | 28px; min 26px | 66px | 230px |
| **LinkedIn link image 1200×627** | 72–79px (6–6.6% W); min 64px | 31px (2.6% W); min 28px | 26px | 53px (4.4% W) | 186px (15.5% W) |

- **Stories:** keep text out of the top 250px and bottom 340px (Instagram's UI covers them). Stories have no caption, so the short web address may go on the tile as the CTA; tell the user to add a link sticker. Monogram 76px tall.
- **Supporting line on social:** the deck under a headline is 60px League Spartan 400 on a post and 64px on a Story, the same on every card; body text on a text-only slide is 44px Lora (50px on a Story). There's room: use it.
- **Key takeaway slides:** the hand-drawn asterisk (`assets/elements/asterisk-mark.png`, ~150px, rotated about −8°) above the eyebrow, **in the eyebrow's color** (gold on dark, ochre on cream, Clean Slate on Calm Blue; recolor it as a mask, never redraw it), then the takeaway in League Spartan 700 at 72px (62px past ~170 characters; 80px on a Story).
- **Corner spot (optional, not every slide):** on a plain light slide, a big watercolor spot can bleed off the bottom-right corner under the logo, like the decorative bleeds on the website's service heroes. Use a brushstroke shape (Spots 5 or 7) or a textured wash (1) in the series' color, its ink about 70% of the card's width with roughly a third off the edges, rotated a few degrees, with a thin black scribble crossing it and running off the edge. Light spots (Calm Blue, gold) keep the dark logo; darker spots (Intentional Blue, ochre, Clean Slate, Steady Blue) knock the logo out to Clear White. Keep the CTA and all text clear of it: the text block must end at least 40px above the spot's ink and must never run beside it. If a slide's text can't clear it, leave the spot off that slide. Use it on alternate inside slides of a series, not every one.
- **Series on a watercolor wash** (carousels, Stories): show a different crop of the same wash on each slide (one continuous wash scaled to ~130% of the frame height, a different position per slide; never tile it). Keep washes occasional: most posts are solid brand colors.
- **Whiteboard and flip-chart photos:** brighten so the paper reads near-white, crop in so the board fills the frame, and nudge the marker colors toward the palette (pink/red → Honest Ochre, blue/purple → Intentional Blue, green/teal → Clean Slate), keeping each stroke's lightness so the handwriting stays natural. Close, not exact.
- **Photos on social are full color.** Case study and session photos appear as shot (the duotone treatment is for the website). Get the originals from the client's photo folders, never the website's duotone copies.
- **Eyebrows on social:** 30px League Spartan 500 (min 28px; the 14px eyebrow is the web size). **Phones show a 1080px card at about a third of its size: nothing on a card goes below 26px** (sources, CTAs), and body copy stays at 36px or more. **Attributions:** a round headshot (170px circle, face-centred crop; place crops with face detection, never cut the face) beside the name whenever we have the person's photo; name 46px League Spartan 700, role 36px Inconsolata with +0.1em tracking (uppercase monospace reads smaller than its size).
- **Headline length:** at most 8 words and 3 lines. Cut words before shrinking type.
- **Body on a tile:** at most 25 words. In feed posts, links go in the post caption, never on the tile.
- **Testimonials:** at most 32 words on a tile. Use one or more complete sentences of the real quote, unedited, no ellipsis; never reword.
- **Template for every social card: `assets/templates/social-series.html`.** It is the renderer that made every card on brand.wbt.coach/social: edit its JSON spec (format, ground, tone, slides of type cover, list, text, quote, takeaway, collage, stat; optional corner spot) and render each slide with `#s=<n>`. It already applies the rules on this page: sizes, safe zones, one cover photo height, collage proportions by ink, the asterisk, corner spots that drop out near text, auto-fit that never shrinks the supporting line, no orphans, and the *Come Together* animation (`#anim=1`). Prefer it over the single-post templates for anything in a series.
- **Carousels and Stories:** for a case study, one slide per beat (cover photo + title → The Challenge → Our Approach → what shifted → client quote → key takeaway); a Story repeats the beats at 1080×1920; a resource Story runs cover → what it's for → what's inside → the link. When a case study tells a beat in prose instead of a list, the slide uses that section's opening sentences word for word (about 20–55 words), never a summary. Quotes: whole sentences only; named people get their name, role and round headshot. Examples: brand.wbt.coach/social.
- **Stat posts:** the line under the number is big, 56–60px Lora (bold lead-in, regular rest): it carries the number's meaning, so it never reads as a footnote.
- **Supporting lines are one size:** the line under a headline (deck) is 60px on a 1080 post, 64px on a Story, on every card in a set; never shrink it to make room. When text runs long, let the picture give way first (a shorter photo, a smaller collage), then the headline.
- **Photo crops keep heads:** never crop the tops of people's heads off; anchor the crop high (object-position near the top) on overhead or group shots. A case-study cover photo takes about half the post's height so the supporting line can be big.
- **No orphans:** no line ends on a single word, in any headline, deck, list item, quote or CTA. Glue the last two words with a non-breaking space and set `text-wrap: pretty`.
- **Same picture size across a set:** every cover photo in a set of posts or Stories is the same height, and every Story collage the same scale. Size them to the longest title so nothing has to shrink.
- **Story pacing:** Stories carry less reading than carousels: about 30 words a screen. Split a long list into frames of one or two points and a long paragraph into frames of whole sentences, at most two frames per beat; leave a point or sentence too long for one screen out of the Story (keep it in the carousel).
- **Animated Stories:** animate each frame with *Come Together*: the photo settles, collage layers and the corner spot converge into place, then the text's words close up line by line (each bullet appears with its own first line), the CTA and logo arrive last, the frame holds long enough to read (about 1.2s + 0.22s per word, 2.5–7s), and everything drifts apart and fades into the next frame. The cover frame holds only briefly (about 2.5s). Lock each line's breaks to the still before moving words (wrap words in spans, insert line breaks, no-wrap), so motion never re-wraps text into the CTA or logo. Join the frames into one 9:16 MP4.
- **The six tile layouts WBT uses** (from the former Social Card Maker): Bold Headline, Watercolor, Split (text panel + image at 42% / 58%), Quote, Stat Card, Photo + Text. Grounds: Steady Blue, Clean Slate, Intentional Blue, Calm Blue, Clear White, or a watercolor background.
- **The line under a headline is the deck: League Spartan 400**, as on the website. Lora is for the body below it. 
- **Quote mark:** Lora italic 700 in Radiant Gold, about 22% of W, never Georgia.
- **Illustration on a tile:** one concept illustration at 26–42% of W, top right or bleeding off an edge. Never under the headline.

## Slides (1920×1080)

From the deck template (`brand.wbt.coach/deck-template/`). Margins 96px left and right, 80px top, 96px bottom. **Logo:** the wordmark 80px tall top-left on the cover and the thank-you slide; the monogram 70px tall bottom-right on content slides; none on dividers. Deck eyebrows follow the deck template (Clean Slate or ochre on light, gold on dark).

| Role | Size | Font |
|---|---|---|
| Cover / divider / thank-you title | 104px | League Spartan 700 |
| Bio name, section index title | 88px | League Spartan 700 |
| Page title | **72px** | League Spartan 700 |
| Quote | 56px | Lora italic |
| Card / step title | 32–38px | League Spartan 700 |
| Lede (under a title) | 30px | League Spartan 400 |
| Body prose | **28px**; min 24px | Lora 400 |
| List items | 24–26px; min 24px | Lora 400 |
| Eyebrow / divider number | 22px | League Spartan 500, caps, +0.16em |
| Impact stat | 220px | League Spartan 700 · Intentional Blue on light (default), Honest Ochre on light, Radiant Gold on dark |

- At most **40 words a slide**, not counting times and labels. Split the slide before shrinking type. Agendas are the exception: a day's agenda may run to 60 words in two columns, at 24px minimum.
- WBT's deck body (28px) is a little under the usual 32px slide minimum. Use 28px for prose and 32px whenever a slide has under 25 words.

## Worksheets and printed resources (US Letter, 8.5×11in)

From resources.wbt.coach. Plain and practical: cream page, white or bordered work areas, the wordmark. **No watercolor backgrounds or collages on worksheets.**

| Role | Size (CSS px at 96dpi → pt) | Font |
|---|---|---|
| Title | 48–62px (36–46pt) | League Spartan 700 |
| Section heading | 19–26px (14–20pt) | League Spartan 700 |
| Lead paragraph | 14–15.5px (10.5–11.5pt) | Lora 400 |
| Body, list items, table cells | **13–13.5px (10pt)**; min 13px | Lora 400 |
| Labels, table heads | 12px (9pt); min 10px | League Spartan 500–700, caps |
| Footer, fine print | 10px (7.5pt) | Inconsolata 500 |

- Margins 0.6–0.75in. One page per sheet unless it's a facilitation guide.
- Fill the page: no near-empty pages, no tiny type floating in white space.
- Write-in lines and boxes: 1px `#E4E2DE` or Grounded Black at 30%, at least 0.35in tall per line.

## Client one-pagers and service overviews (US Letter)

Unlike worksheets, these may carry the service collage (top or bleeding off a corner) and a Steady Blue panel, like the service pages. Margins 0.6in.

| Role | Size | Font |
|---|---|---|
| Feature heading (uppercase) | 44–56px | League Spartan 700 |
| Italic “that…” subhead | 20–24px | Lora italic |
| Deck under a heading | 17–18px | League Spartan 400 |
| Eyebrow | 12px, +0.16em | League Spartan 500, ochre on light / gold on dark |
| Body | 13.5–14px; min 13px | Lora 400 |
| Quote | 16–18px | Lora italic |

- **PDF:** `bash scripts/render.sh file.html out.pdf --pdf` (Letter, no margins, backgrounds on). Check the PDF is one page and nothing runs off it.
- **Arrows in print:** `→` on calls to action (“Book a call →”); never `↗`.

## Email (Field Notes newsletter)

600px content column (640px outer). Works in Gmail and Outlook, so system-safe fallbacks follow every brand font.

| Role | Desktop | Phone (≤ 480px) | Font |
|---|---|---|---|
| Hero headline | 46px | 34px | League Spartan 700 |
| Deck under the headline | 19px | 19px | League Spartan 400 |
| Section heading | 28px | 24px | League Spartan 700 |
| Sub-heading | 20px | 20px | League Spartan 500 |
| Lead paragraph | 19px | 19px | Lora 400 |
| Body, lists | 17px; min 16px | 17px | Lora 400 |
| Pull quote | 22px | 19px | Lora italic |
| CTA heading | 32px | 26px | League Spartan 700 |
| Eyebrow | 14px | 14px | League Spartan 500, caps, +0.16em |

Art inside an email (collages, headers) is a PNG at 2× (1200px wide), with alt text.

## Data pages and dashboards

Reports, trackers, tables of numbers and dashboards (tools.wbt.coach): **sans serif throughout. WBT data pages never use Lora.** League Spartan for headings, labels and table text; Inconsolata for figures that must align. Data-viz series order and contrast rules are in `brand-context.md`.

## Web (workbettertogether.coach)

| Role | 1440 desktop | 390 phone |
|---|---|---|
| Display / big feature heading | 80px (clamp 40–82px) | 40px |
| H1 | 56px | 36px |
| H2 | 40px | 30px |
| H3 | 28px | 22px |
| Deck (`.lede-thin`) | 26px | 20px |
| Body | 16–19px Lora, lh 1.75 | 16–17px |
| Eyebrow | 14px | 14px |
| Buttons | 14px Inconsolata, 44px tall min | same |

Content column about 1080px, page padding 40px horizontal. Phones: one column, nothing wider than the screen.
