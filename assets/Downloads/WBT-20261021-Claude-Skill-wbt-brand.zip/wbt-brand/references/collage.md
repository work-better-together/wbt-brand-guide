# Collages

How to build a WBT collage from a concept: watercolor spot → scribble → illustration. (Merged from the former `wbt-collage` skill, Oct 2026.) The Collage Maker at https://brand.wbt.coach/collage-maker.html does the same thing interactively. A finished collage from the catalog (Finished Collages) may also be placed as-is.

## Inputs

- **Concept** (required) — what the collage should express, e.g. "clarity", "new ideas", "team collaboration", "resilience", "the bigger picture", "emotional intelligence". Ask for it if not given.
- **Color** (optional) — a brand color, or a page context (leadership→Gold, team→Intentional Blue, facilitation→Ochre). Otherwise choose per the concept's feel.
- **Output** (optional) — a **standalone PNG** (default) or an **embeddable HTML block** for a page.

## Step 1 — Read the concept map

Use the concept map, colors and scribble guide below (part 2 of this file). Exact file names, sizes and ink bounds are in `asset-catalog.md`.

## Step 2 — Choose the three assets

**Color by context:** service pieces use their service color (Leadership gold, Team Intentional Blue, Facilitation ochre). The Insights main page uses Calm Blue; individual Insights articles may use any of the seven spot colors, picked to fit the topic and varied from the last few articles.

1. **Illustration** — match the concept to the tag map in Part 2 below. Pick the single illustration that most clearly expresses it. State your pick and why in one line (e.g. *"clarity → Lightbulb-Glowing (ideas/illumination)"*). If two read equally well, prefer the cleaner silhouette; pick singular vs. plural to fit the message (e.g. `Bees-Pair` for a duo, `Bees-Trio` for a small team).
2. **Color + spot** — choose the color by rule 1→2→3 in the catalog, then a spot **shape** `-1..-9`. **Vary the shape every time** — rotate through 1–9, don't keep grabbing `-1`/`-2`.
3. **Scribble** — pick a **large, expressive** one, and a **genuinely different file each time** (we have ~350 across 12 categories — rotate widely). Steer by mood: Loops/Sweeps = graceful, Waves/Lines/Ornamental = calm/simple, Hearts = emotional-intelligence. **Favor single-stroke scribbles** (Loops, Sweeps, Waves, single Lines) — they read cleanly when big. **Chaotic and Blocks are dense** and will swallow the illustration when enlarged, so use them only when you deliberately want the scribble to dominate.

### ⚠️ Variety is required
Never reuse the same spot shape or scribble file across collages. Before choosing, check recent picks: the other collages in the same set or campaign (vary color, spot shape and scribble across them), and `ls assets/collages/*/` if you have a local project (or check the source filenames already copied) and deliberately pick assets you haven't used. Rotate the **color**, the **spot shape (1–9)**, and especially the **scribble** (different file *and* often a different category) so no two collages look alike.

## Step 3 — Stage the assets

Download the three chosen files so the collage is self-contained (URL-encode spaces):

```sh
B="https://brand.wbt.coach/assets"
mkdir -p assets/collages/<slug>
curl -sfo assets/collages/<slug>/illustration.png "$B/Illustrations/<Illustration>.png"
curl -sfo assets/collages/<slug>/spot.png         "$B/Watercolor%20Textures/Spots/<Color>/WBT-...-Spots-<N>.png"
curl -sfo assets/collages/<slug>/scribble.png     "$B/Scribbles/<Category>/<file>.png"
```

`<slug>` = concept in kebab-case (e.g. `clarity`, `team-collaboration`).

## Step 4 — Compose the collage

Build an HTML stage with the three layers absolutely positioned and **overlapping**. Transparent background. Layer order is fixed: **spot (z1) → scribble (z2) → illustration (z3)**.

Starting template (tune the numbers in Step 5):

```html
<div class="wbt-collage" style="position:relative; width:640px; height:560px; background:transparent;">
  <img src="assets/collages/<slug>/spot.png"         style="position:absolute; z-index:1; width:90%;  left:5%;  top:12%;">
  <img src="assets/collages/<slug>/scribble.png"     style="position:absolute; z-index:2; width:88%;  left:6%;  top:22%; transform:rotate(-6deg);">
  <img src="assets/collages/<slug>/illustration.png" style="position:absolute; z-index:3; width:48%;  left:28%; top:16%;">
  <!-- Narrow illustration (hourglass/key/lamppost)? Push spot to ~120–145% so it clears the silhouette. -->
</div>
```

**Proportions (match the resources.wbt.coach category collages: `assets/examples/07-collage-proportions.jpg`):**
- **The illustration leads.** Size the collage by the illustration's ink (its larger side = L).
- **Spot ≈ the illustration's size** (about 1.0 L; up to 1.7× the width of a narrow illustration like a lightbulb), shifted about 25% of L to one side and a little down, so it peeks out from behind on one side. Not a big halo, not hidden.
- **Scribble ≈ 1.25–1.35 L**, centred on the illustration, its thin loops wrapping it (over the spot, under the illustration); a short tail may escape. Use thin scribbles (catalog `line` ≤ 10).
- On a 1080px post the illustration is about 40–45% of the card's width.
- **Balance optically, not just by measurement.** A dense, dark illustration (the full moon) carries far more visual weight than an open, airy one (the bees) at the same size, and a saturated spot (Intentional Blue, Steady Blue) weighs more than a light one (Calm Blue, gold). Size each collage so its visual weight matches the others: shrink dense subjects, enlarge sparse ones (roughly 0.75–1.3×), then look at a set side by side and adjust until no collage shouts or whispers.

**Composition rules (from the finished collages):**
- **The scribble's ink sits over the spot and under the illustration.** Place it by its ink bounds from `asset-catalog.md`: centre the scribble's ink on the spot's ink and size it so the ink is about as wide as the spot's ink (0.9–1.2×). A scribble whose ink mostly misses the spot reads as a stray line; the self-check fails it.
- The **illustration is the anchor** — largest *single* read, roughly centered, sized by its natural aspect (tall items like a lightbulb are governed by height, wide items by width). Aim for it to occupy ~45–65% of the stage.
- The **watercolor spot sits behind and offset** so it peeks out on one or two sides (a colored halo), not perfectly concentric. **Size it by silhouette, not by a fixed %:** the spot must clearly clear the illustration's outline on 2+ sides, so a *narrow* illustration (hourglass, key, lamppost) needs a spot **much wider than the illustration** — often ~120–145% of the *stage* (roughly 2.5–3× the illustration's width) — or it just hides behind the cut-out and reads as a thin sliver. When in doubt, make the spot bigger; a spot that only peeks on one edge is too small.
- The **scribble** should feel hand-drawn and loose — but it competes with the spot for weight, so **balance the two against each other**, not against fixed numbers. A big spot wants a scribble pulled *in and up* to tangle around the illustration's waist (~65–80% of stage), while a small/subtle spot can carry a sweeping ~90–120% scribble spanning past the edges. A scribble that sits entirely *below* the illustration reads as a "pile at the base" — raise it so it weaves across and over the spot. Rotate/flip for a natural gesture; never small, centered, or timid.
- **Judge the three sizes *relatively*, in the screenshot.** The common failure is a spot that looks fine in isolation but tiny next to an oversized scribble. If one element dominates, shrink it or grow the others until no single piece swallows the rest.
- Everything **overlaps**; nothing floats alone. Keep a little asymmetry — offset each element from the others.
- Only three elements by default. Add a second scribble or a `Blue-Blob`/`Pink-Torn-Paper` accent only if the user wants a richer collage.

## Step 5 — Render, verify, iterate

Collage arrangement is aesthetic — **always verify visually and adjust**:
1. Write the stage into a tiny standalone file (e.g. `assets/collages/<slug>/preview.html`) with the div above centered on a cream (`#F9F8F2`) background.
2. Render it: headless Chrome (`--headless=new --screenshot=out.png --window-size=W,H file://…/preview.html`) or a local preview server, then look at the PNG.
3. Adjust sizes/offsets/rotation until it matches the finished-collage feel (dominant illustration, peeking halo, curling scribble). Re-shoot.

## Step 6 — Deliver

- **Standalone PNG (default):** once it looks right, render the stage as a transparent PNG: `TRANSPARENT=1 bash scripts/render.sh preview.html collage.png W H` with no background on the page or the stage (or screenshot the stage tightly and save the image (or tell the user the `preview.html` is ready to export). The three source PNGs already live in `assets/collages/<slug>/`.
- **Embed in a page:** hand back the `<div class="wbt-collage">…</div>` block (paths relative to the target page) to drop into a hero/section, or wire it into a `.hero-svc`-style layout as done for the mobile service headers.

## Guardrails
- Only use brand assets from `BRAND_ASSETS` — never invent or fetch other imagery.
- Scribbles stay black, as drawn: never invert or recolor them for a dark ground.
- Keep the background transparent; the watercolor spot is the only fill.
- Match a page's colorway when the collage is for a specific WBT page.
- Don't stretch/distort — scale illustrations proportionally.
- If the concept has no clear illustration match, say so and offer the two closest options rather than forcing a poor fit.


---

# Part 2 · Concept map, colors and scribbles

All source assets are served by the live brand guide:

```
BRAND_ASSETS="https://brand.wbt.coach/assets"
```

URL-encode spaces (`Watercolor%20Textures`, `Finished%20Collages`) and download what you need with curl, then composite locally. The same folders also sit in the shared Google Drive folder `Work Better Together/Brand/2026 WBT Brand Guide/assets/` (find a file by its exact name with a Drive connector). If both fail, say so and ask the user to attach the assets; never draw a stand-in.

For every file's exact name, pixel size and where its ink sits inside the canvas, see `asset-catalog.md` in this folder.

Sub-paths:
- Illustrations: `$BRAND_ASSETS/Illustrations/<Name>.png`
- Watercolor spots: `$BRAND_ASSETS/Watercolor Textures/Spots/<Color>/WBT-20260403-<ColorFile>-Watercolor-Spots-<1..9>.png`
- Scribbles: `$BRAND_ASSETS/Scribbles/<Category>/<file>.png`
- Finished-collage examples (for style reference only): `$BRAND_ASSETS/Finished Collages/*.png`

Every asset is a transparent PNG, except `Tree-Roots.png`, which sits on a gray disc (use it as a disc or pick another). File names don't always say what's pictured (`Resilience.png` is a camel): download and look before you commit to one. Illustrations are black-and-white cut-outs; spots are single-color watercolor blobs; scribbles are thin black line art.

---

## 1. Illustrations — pick by CONCEPT (tag match)

Choose the ONE illustration whose concept best expresses the user's idea. Match on the tags below (and obvious synonyms). If several fit, prefer the one that reads most clearly as a single silhouette. Use the plural/singular that fits the message (e.g. one bee vs. a trio).

| Illustration file | Concept group | Tags / when to use |
|---|---|---|
| `Lightbulb-3D.png`, `Lightbulb-Glowing.png`, `Lightbulb-Pendant.png`, `Street-Lamp.png` | **Ideas & Light** | ideas, innovation, brainstorming, illumination, clarity, insight, a-ha moments, bright idea, creativity |
| `Full-Moon.png`, `Planet-Mars.png`, `Planet-Neptune.png`, `Saturn-Rings.png` | **Cosmos & Wonder** | vision, ambition, perspective, the bigger picture, wonder, aspiration, long-term, possibility, exploration |
| `Eye.png`, `Eye-Rays.png`, `Gold-Blue-Eye.png`, `Hands-With-Eyes.png`, `Mirror.png` | **Perception & Reflection** | assessment, perception, bias, reflection, self-awareness, seeing clearly, noticing, observation, insight |
| `Heart.png`, `Heart-1.png`, `Heart-2.png`, `Heart-3.png`, `Heart-Tablet.png` | **Emotional Intelligence** | emotional intelligence, empathy, feedback, care, connection, compassion, relationships |
| `Hourglass.png`, `Watch.png` | **Time, Stress, Assessment** | time, stress, urgency, agenda, pacing, patience, the stopwatch, deadlines, endurance |
| `Key.png`, `Open-Doors.png`, `Map.png` | **Growth & Development** | growth, development, leadership, direction, unlocking potential, the path forward, opportunity, next step, navigation |
| `Roots.png`, `Tree-Roots.png`, `Nest.png`, `Nest-Bird.png`, `Red-Butterfly.png` | **Renewal & Resilience** | renewal, resilience, psychological safety, grounding, transformation, growth from within, stability, belonging, rebirth |
| `Sun.png`, `Sun2.png`, `Rays.png`, `Star.png`, `Star-Colors.png` | **Energy & Motivation** | motivation, energy, brainstorming, team spotlight, renewal, optimism, recognition, warmth, shining |
| `Bee-Single.png`, `Bees-Pair.png`, `Bees-Trio.png` | **Team & Collaboration** | team coaching, collaboration, collective intelligence, hive mind, working together, partnership (pair = 2:2 / duo; trio = small team) |
| `Blue-Blob.png`, `Pink-Blob.png`, `Pink-Torn-Paper-1.png`, `Pink-Torn-Paper-2.png` | **Layout accents (rarely the focal)** | backgrounds, collage moments, behind-text accents — use only as an extra texture, not as the concept illustration |
| `Cairn.png`, `Armillary.png` | **Grounding & Orientation** | cairn = building together, balance, steady progress, trail markers; armillary = navigation, orienting to the bigger picture |

> The rows above are the original etched/watercolor set. The table below adds the **Concept Library** — 63 photographic/etched illustrations synced from the WBT Airtable ("Visual Architecture" table) and vendored into `$BRAND_ASSETS/Illustrations/` on 2026-07-08. These are tagged to **specific WBT training & coaching concepts**, so prefer them when the user's idea names one of these concepts directly; fall back to the thematic set above for looser/mood-based concepts.

### 1b. Concept Library illustrations (WBT training & coaching concepts)

| Concept | Illustration file(s) | Tags / when to use |
|---|---|---|
| Case Study | `Case-Study-2.png`, `Case-Study-3.png` | case study, example, evidence, proof point, results, story, documentation (paper clip, card catalog) |
| Collaboration (cairn) | `Cairn.png`, `Cairn-2.png` | collaboration, building together, shared effort, balance, stacking, steady teamwork |
| Small Group Breakouts | `Small-Group-Breakouts.png` | small group, breakout, subgroups, workshop rotation, orbits |
| Break | `Break.png` | break, pause, rest, coffee, intermission |
| Agenda | `Agenda.png` | agenda, plan, schedule, session outline, roadmap for the day (notepad, telegraph) |
| Renewal | `Renewal.png` | renewal, refresh, replenish, nurture, watering can |
| Assessment | `Assessment.png`, `Assessment-4.png` | assessment, evaluation, measurement, diagnostic, baseline (eye chart, stopwatch) |
| Perception & Bias | `Perception-And-Bias.png` | perception, bias, lens, point of view, blind spots, seeing clearly |
| Managing Up & Across | `Managing-Up.png` | managing up, managing across, hierarchy, navigating the system, stakeholders (knights facing off) |
| Resilience (team) | `Resilience-Team.png`, `Resilience-Team-2.png` | team resilience, withstanding pressure, holding together, group endurance (dominoes, card pyramid) |
| Team Cohesion | `Tandem-Bicycle.png`, `Team-Cohesion-2.png` | team cohesion, alignment, moving together, in sync, coordination (tandem bicycle) |
| Brainstorming | `Brainstorm.png`, `Brainstorming-2.png` | brainstorming, ideation, generating ideas, aiming, spark (lightning bolt, loaded bow) |
| Welcome | `Welcome.png` | welcome, hospitality, opening, greeting, kickoff (pineapple) |
| Lunch | `Lunch.png` | lunch, meal, midday break, food (sandwich) |
| Motivation | `Motivation.png`, `Motivation-2.png` | motivation, drive, momentum, ignition, spark (propeller, matchbook) |
| Resilience (individual) | `Resilience.png`, `Concept-Noodles.png` | individual resilience, perseverance, adaptability, bouncing back, endurance |
| Difficult Conversations | `Difficult-Conversations.png`, `Difficult-Conversations-2.png`, `Communication.png` | difficult conversations, hard talks, candor, speaking up, communication (typewriter, old radio) |
| Leadership | `Leadership.png`, `Leadership-2.png`, `Leadership-3.png`, `Horsebell.png` | leadership, guiding, steering, direction (hot air balloon, helm, compass, horsebell) |
| Psychological Safety | `Psychological-Safety.png`, `Psychological-Safety-2.png`, `Psychological-Safety-3.png`, `Psychological-Safety-4.png` | psychological safety, trust, safety, protection, belonging (birdhouse, lock, caution tape) |
| Team Spotlight | `Team-Spotlight.png` | team spotlight, recognition, highlight, celebrating the team (bowling pins) |
| Emotional Intelligence | `Emotional-Intelligence-1.png`, `Heart-2.png` | emotional intelligence, empathy, self-awareness, feelings (barometer, newsprint heart) |
| Thank You | `Thank-You.png` | thank you, gratitude, appreciation, closing, acknowledgment |
| Growth & Development | `Growth-And-Development-1.png`, `Growth-And-Development-2.png` | growth, development, reframing, learning, unlocking (frame, antique key) |
| Conflict Management | `Conflict-Management.png`, `Conflict-Management-2.png` | conflict management, tension, disagreement, resolving conflict (hazmat caution, skull) |
| Collaboration (gears) | `Collaboration.png`, `Collaboration-3.png` | collaboration, working together, cooperation, coordination (pinwheel, gears in tandem) |
| Reflection | `Reflection.png`, `Reflection-2.png` | reflection, introspection, looking inward, self-review (looking glass, crystal ball) |
| Stress | `Stress-1.png`, `Stress-2.png`, `Stress-3.png` | stress, pressure, overwhelm, burnout, tension (alarm bells, frayed rope) |
| Feedback / Contact | `Feedback.png`, `Feedback-Contact.png`, `Communication-2.png` | feedback, contact, get in touch, input, response (feather quill, letterbox, boombox) |
| Resource | `Resource.png`, `Resource-2.png` | resource, materials, reference, tools, learning materials (antique books, needle & thread) |
| Extras (misc) | `Heart-1.png`, `Heart-3.png`, `Windmill.png`, `Telegraph.png`, `Extra-39.png` | grab-bag: hearts = warmth/EI; windmill = energy/momentum; telegraph = communication/agenda |
| More Extras (misc) | `Target.png`, `Fusebox.png`, `Spring.png`, `Sundial.png` | grab-bag: target = goals/focus; fusebox = energy/power; spring = momentum/bounce; sundial = time/pacing |

> Full authoritative tag list: https://brand.wbt.coach/elements.html#images
> Three Airtable concepts have icon suggestions but **no illustration uploaded yet** — for these, fall back to the thematic set above: **Team Coaching** (→ Ideas & Light lightbulbs), **Facilitation + Training** (→ Street-Lamp / lightbulbs), **Leadership Coaching** (→ Cosmos & Wonder moon/planets).

---

## 2. Watercolor spots — pick a COLOR, then a shape

Seven brand colors, nine spot shapes each (`-1` … `-9`). Filenames:
`$BRAND_ASSETS/Watercolor Textures/Spots/<Color>/WBT-20260403-<ColorFile>-Watercolor-Spots-<N>.png`

| Color (folder) | `<ColorFile>` in filename | Hex | Feel |
|---|---|---|---|
| Radiant Gold | `Gold` | `#CD9F36` | warmth, optimism, energy — **leadership** |
| Intentional Blue | `Intentional-Blue` | `#2531A5` | focus, action, trust — **team** |
| Honest Ochre | `Honest-Ochre` | `#B55312` | tension, challenge, grounding — **facilitation** |
| Steady Blue | `Steady-Blue` | (deep navy) | calm authority, depth |
| Calm Blue | `Calm-Blue` | (soft blue) | ease, openness, safety |
| Clean Slate | `Clean-Slate` | (light gray-blue) | neutrality, clarity, a fresh start |
| Grounded Black | `Grounded-Black` | (near-black) | seriousness, weight, contrast |

**How to choose the color:**
1. If the collage is for a specific WBT service page/context, match that colorway: leadership→Gold, team→Intentional Blue, facilitation→Ochre.
2. Otherwise pick the color whose *feel* fits the concept (e.g. resilience→Steady/Calm Blue, energy→Gold, challenge→Ochre).
3. When unsure, default to **Radiant Gold** or **Intentional Blue** (the two most common).

Pick any shape `-1..-9`; they're interchangeable organic blobs. `-1`/`-2`/`-3` tend to be the fullest, roundest blobs (good default backdrops).

---

## 3. Scribbles — pick a flowing accent

`$BRAND_ASSETS/Scribbles/<Category>/<file>.png`. For collages, prefer thin, organic, looping line art. Best categories:

| Category | Count | Good for | Example files |
|---|---|---|---|
| **Loops** | 4 | signature curly accents (the collage default) | `WBT-scribble-cascading-ovals.png`, `WBT-scribble-double-oval-tail.png`, `WBT-scribble-loop-wavy-tail.png`, `WBT-scribble-overlapping-ovals.png` |
| **Sweeps** | 2 | one long graceful gesture | `WBT-scribble-long-sweep-spiral.png`, `WBT-scribble-s-curve-loop.png` |
| **Waves** | 1 | a calm undulating line | `WBT-scribble-looping-wave.png` |
| **Chaotic** | 63 | energetic tangles | `WBT-scribble-chaotic-01.png` … `-63.png` |
| **Lines** | 50 | minimal single strokes | `WBT-scribble-line-01.png` … `-50.png` |
| **Straight** | 60 | underlines / straight marks | `WBT-scribble-straight-01.png` … `-60.png` |
| Ornamental (30), Blocks (38), Misc (50), Backgrounds (21), Botanical (2), Hearts (3) | — | specialty — use only if the concept calls for it | — |

**Default:** a **Loops** or **Sweeps** scribble. Use **Chaotic** for high-energy concepts, **Waves/Lines** for calm/minimal ones, **Hearts** for emotional-intelligence concepts.
